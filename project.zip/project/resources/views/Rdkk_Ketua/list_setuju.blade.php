@extends('Layouts.master')

@section('content')
<div class="main">
  <div class="main-container">
    <div class = "container-fluid">
      <div class = "row">
        <div class = "col-md-12">
          <div class="panel">
				    <div class="panel-heading">
              <h2 class="panel-title"><b><p class="text-center">Daftar Pengajuan Telah Disetujui</p></b></h2>
                <div class="right">
                @if(auth()->user()->role=='kelompok')
                  <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>  
                @endif
                </div>
						</div>
						<div class="panel-body">
            @if(Session::has('sukses'))
              <div class="alert alert-success" role="alert">
                {{Session('sukses') }}
              </div>
            @endif             
						<table class="table table-hover">
							<thead>
								<tr>
                  <td>No</td>
                  <td>Nama Kelompok</td>
                  <td>Alamat</td>
                  <td>Nama Pengecer</td>
                  <td>Status</td>
         
                  <td>AKSI</td>
								</tr>
						  </thead>
              <tbody>
                @foreach($rdkk as $result => $hasil)
                <tr>
                  <td>{{$result + 1}}</td>
                  <td>{{$hasil->nama_kelompok}}</td>
                  <td>{{$hasil->alamat}}</td>
                  <td>{{$hasil->nama_pengecer}}</td>
                  <td>{{$hasil->status_dinper}}</td>
                  <td><a href="{{route('Pengajuan-rdkk.show',$hasil->id)}}" class="badge badge-infor"><i class="lnr lnr-eye"></i></a>
                     
                  </td>
                </tr>
                @endforeach     
						  </tbody>
						</table>
   
					</div>
				</div>
      </div>
    </div>
  </div>
</div>

@endsection()