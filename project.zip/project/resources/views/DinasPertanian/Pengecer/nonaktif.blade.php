@extends('Layouts.master')

@section('content')
<div class="main">
    <div class="main-container">
      <div class = "container-fluid">
         <div class = "row">
            <div class = "col-md-12">
            <br>
              <div class="panel">
			    <div class="panel-heading">
          <h2 class="panel-title"><b><p class="text-center">DATA PENGECER YANG SUDAH TIDAK BEROPERASI</p></b></h2>
				</div>
				<div class="panel-body">
                @if(Session::has('sukses'))
                <div class="alert alert-success" role="alert">
                 {{Session('sukses') }}
                </div>
                @endif
				<table class="table table-hover">
					<thead>
						<tr>
                            <td>No</td>
                            <td>ID</td>
                            <td>NAMA PENGECER</td>
                            <td>REGION</td>
                            <td>ALAMAT</td>
                            <td>AKSI</td>
						</tr>
					</thead>
					<tbody>
            @foreach($data_pengecer as $result => $hasil)
            <tr>
              <td>{{$result + $data_pengecer->firstitem()}}</td>
              <td><a>{{$hasil->pengecer_id}}</a></td>
              <td><a>{{$hasil->name}}</a></td>
              <td>{{$hasil->region}}</td>
              <td>{{$hasil->address}}</td>
              <td>
              <form action="/Pengecer/{{$hasil->id}}/kill" method="POST">
                <a href="/Pengecer/{{$hasil->id}}/aktif" class="btn btn-primary btn-sm">Aktif</a>
                @csrf
                @method('delete')
              <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin menghapus secara permanen??')">Delete</button>
              </form>
                </td>
              </tr>
              @endforeach
            </tbody>
				</table>
        {{$data_pengecer->links()}}
			      </div>
		      </div>
        </div>
      </div>
    </div>
  </div>
</div> 

@endsection