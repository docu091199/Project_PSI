@extends('Layouts.master')

@section('content')
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">UBAH DATA RDKK</p></b></h1>
                        </div>
                        <div class="panel-body">
                            @if(Session::has('sukses'))
                                <div class="alert alert-success" role="alert">
                                {{Session('sukses') }}
                                </div>
                            @endif
                            <form action = "#" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group {{$errors->has('nama_kelompok') ? 'has-error' : ''}}">
                                    <label for="nama_kelompok">Nama Kelompok </label>
                                    <input type="text" class="form-control" name="nama_kelompok"  value="{{$rdkk->nama_kelompok}}">
                                @if($errors->has('nama_kelompok'))
                                    <span class="help-block">{{$errors->first('nama_kelompok')}}</span>
                                @endif
                                </div>
                                <div class="form-group {{$errors->has('alamat') ? 'has-error' : ''}}">
                                    <label for="alamat">Alamat</label>
                                    <input type="text" class="form-control" name="alamat"  value="{{$rdkk->alamat}}">
                                @if($errors->has('alamat'))
                                    <span class="help-block">{{$errors->first('alamat')}}</span>
                                @endif
                                </div>
                                <div class="form-group {{$errors->has('nama_pengecer') ? 'has-error' : ''}}">
                                    <label for="nama_pengecer">Nama Pengecer</label>
                                    <select name="jenis_kelamin" class="form-control" id="nama_pengecer">
                                        <option>select...</option>
                                        @foreach($pengecer as $data => $hasil)
                                        <option value="{{$rdkk->nama_pengecer}}">{{$hasil->nama_pengecer}}</option>
                                        @endforeach
                                    </select>
                                @if($errors->has('nama_pengecer'))
                                    <span class="help-block">{{$errors->first('nama_pengecer')}}</span>
                                @endif
                                </div>
                                <div class="form-group {{$errors->has('luas_tanah') ? 'has-error' : ''}}">
                                    <label for="luas_tanah">Luas Tanah</label>
                                    <input type="text" class="form-control" name="luas_tanah"  placeholder="Masukkan Luas Tanah" value="{{$rdkk->luas_tanah}}">
                                @if($errors->has('luas_tanah'))
                                    <span class="help-block">{{$errors->first('luas_tanah')}}</span>
                                @endif
                                </div>
                                <div class="form-group {{$errors->has('jumlah_pupuk') ? 'has-error' : ''}} ">
                                    <label for="jumlah_pupuk">Jumlah Pupuk</label>
                                    <input type="text" name="avatar" class="form-control"  value="{{$rdkk->jumlah_pupuk}}">
                                @if($errors->has('jumlah_pupuk'))
                                    <span class="help-block">{{$errors->first('jumlah_pupuk')}}</span>
                                @endif
                                </div>
                                <button type="submit" class="btn btn-warning btn-sm">Update</button>
                            </form>
                        </div>
                    </div>
                </div>			       
            </div>
        </div>
    </div>
</div>
@endsection