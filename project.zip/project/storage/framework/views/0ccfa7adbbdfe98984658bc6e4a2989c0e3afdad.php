

<?php $__env->startSection('content'); ?>
  <div class="main">
      <div class="main-container">
          <div class = "container-fluid">
            <div class = "row">
              <div class = "col-md-12">
              <br>
              <div class="panel">
								<div class="panel-heading">
                <h2 class="panel-title"><b><p class="text-center">DATA KELOMPOK TANI</p></b></h2>
                  <div class="right">
                    <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>
                </div>
								</div>
								<div class="panel-body">
                <?php if(Session::has('sukses')): ?>
                  <div class="alert alert-success" role="alert">
                 <?php echo e(Session('sukses')); ?>

                 </div>
                <?php endif; ?>
									<table class="table table-hover">
										<thead>
											<tr>
                        <td>No</td>
                        <td>ID</td>
                        <td>NAMA KELOMPOK</td>
                        <td>NAMA KETUA</td>
                        <td>JUMLAH ANGGOTA</td>
                        <td>AKSI</td>
											</tr>
										</thead>
										<tbody>
                 <?php $__currentLoopData = $data_keltan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($result + $data_keltan->firstitem()); ?></td>
                        <td><a href="/KelompokTani/<?php echo e($hasil->id); ?>/profile"><?php echo e($hasil->keltan_id); ?></a></td>
                        <td><a href="/KelompokTani/<?php echo e($hasil->id); ?>/profile"><?php echo e($hasil->name); ?></a></td>
                        <td><?php echo e($hasil->leader); ?></td>
                        <td><?php echo e($hasil->member); ?></td>
                        <td><a href="/KelompokTani/<?php echo e($hasil->id); ?>/edit" class="btn btn-warning btn-sm"> Edit</a>
                        <a href="/KelompokTani/<?php echo e($hasil->id); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin mengganti status??')">Non Aktif</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
                <?php echo e($data_keltan->links()); ?> 
								</div>
							</div>
            </div>
          </div>
        </div>
      </div>
  </div> 

  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Masukkan Data Kelompok Tani</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "/KelompokTani/create" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('keltan_id') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">ID Kelompok Tani</label>
                <input type="text" class="form-control" name="keltan_id"  placeholder="Masukkan ID" value="<?php echo e(old('keltan_id')); ?>">
                <?php if($errors->has('keltan_id')): ?>
                  <span class="help-block"><?php echo e($errors->first('keltan_id')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Nama Kelompok</label>
                <input type="text" class="form-control" name="name" placeholder="Masukkan Nama Kelompok" value="<?php echo e(old('name')); ?>">
                <?php if($errors->has('name')): ?>
                  <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('leader') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Nama Ketua</label>
                <input type="text" class="form-control" name="leader"  placeholder="Masukkan Nama Ketua" value="<?php echo e(old('leader')); ?>">
                <?php if($errors->has('leader')): ?>
                  <span class="help-block"><?php echo e($errors->first('leader')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('birth') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Tanggal dibentuk</label>
                <input type="date" class="form-control" name="birth"  value="<?php echo e(old('birth')); ?>">
                <?php if($errors->has('birth')): ?>
                  <span class="help-block"><?php echo e($errors->first('birth')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('wilayah') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Luas Wilayah</label>
                <input type="text" class="form-control" name="wilayah"  placeholder="Masukkan Jumlah Luas Wilayah (dalam satuan Hh)" value="<?php echo e(old('wilayah')); ?>">
                <?php if($errors->has('wilayah')): ?>
                  <span class="help-block"><?php echo e($errors->first('wilayah')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Email</label>
                <input type="email" class="form-control" name="email"  placeholder="Masukkan Email" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                  <span class="help-block"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('member') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Jumlah Anggota</label>
                <input type="text" class="form-control" name="member"  placeholder="Masukkan Jumlah Anggota" value="<?php echo e(old('member')); ?>">
                <?php if($errors->has('member')): ?>
                  <span class="help-block"><?php echo e($errors->first('member')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Avatar</label>
                  <input type="file" name="avatar" class="form-control"  value="<?php echo e(old('avatar')); ?>">
            </div>
            <div class="form-group form-check <?php echo e($errors->has('avatar') ? 'has-error' : ''); ?>">
                <?php if($errors->has('avatar')): ?>
                  <span class="help-block"><?php echo e($errors->first('avatar')); ?></span>
                <?php endif; ?>
            </div>
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/Keltan/index.blade.php ENDPATH**/ ?>