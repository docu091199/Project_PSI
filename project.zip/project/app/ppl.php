<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ppl extends Model
{
    protected $table = 'ppl';
    protected $fillable=['ppl_nip','ppl_name','jenis_kelamin','allocation_place','users_id','avatar'];

    public function getAvatar(){
        if(!$this->avatar){
            return asset('images/default.png');
        }

        return asset('images/'.$this->avatar);
    }
    use softDeletes;
}
