

<?php $__env->startSection('content'); ?>
<div class="main">
  <div class="main-container">
    <div class = "container-fluid">
      <div class = "row">
        <div class = "col-md-12">
        <br>
          <div class="panel">
			<div class="panel-heading">
              <h2 class="panel-title"><b><p class="text-center">DATA PUPUK BERSUBSIDI</p></b></h2>
                <div class="right">
                  <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>  
                </div>
				</div>
				<div class="panel-body">
            <?php if(Session::has('sukses')): ?>
              <div class="alert alert-success" role="alert">
                <?php echo e(Session('sukses')); ?>

              </div>
            <?php endif; ?>             
			<table class="table table-hover">
				<thead>
				<tr>
                  <td>No</td>
                  <td>KODE</td>
                  <td>NAMA PUPUK</td>
                  <td>JENIS PUPUK</td>
                  <td>HARGA</td>
                  <td>JUMLAH PEMESANAN PUPUK</td>
                  <td>AKSI</td>
				</tr>
				</thead>
                <tbody>
                <?php $__currentLoopData = $data_pupuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($result + $data_pupuk->firstitem()); ?></td>
                  <td><?php echo e($hasil->pupuk_id); ?></a></td>
                  <td><?php echo e($hasil->name); ?></a></td>
                  <td><?php echo e($hasil->jenis); ?></td>
                  <td>Rp. <?php echo e($hasil->harga); ?> /kg</td>
                  <td> <?php echo e($hasil->jumlah_pupuk); ?> kg</td>
                  <td><a href="/Pupuk/<?php echo e($hasil->id); ?>/edit" class="btn btn-warning btn-sm"> Edit</a>
                      <a href="/Pupuk/<?php echo e($hasil->id); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin mengganti status??')">Delete</a>
                  </td>
                </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
				</tbody>
			</table>
          <?php echo e($data_pupuk->links()); ?> 
			</div>
		</div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Masukkan Data Pupuk</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "/Pupuk/create" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('pupuk_id') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">KODE</label>
                <input type="text" class="form-control" name="pupuk_id"  placeholder="Masukkan KODE PUPUK" value="<?php echo e(old('pupuk_id')); ?>">
                <?php if($errors->has('pupuk_id')): ?>
                  <span class="help-block"><?php echo e($errors->first('pupuk_id')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">NAMA PUPUK</label>
                <input type="text" class="form-control" name="name"  placeholder="Masukkan Nama Pupuk" value="<?php echo e(old('name')); ?>">
                <?php if($errors->has('name')): ?>
                  <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('jenis') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">PILIH JENIS PUPUK</label>
                <select name="jenis" class="form-control" id="exampleformControlSelect1">
                    <option placeholder>select...</option>
                    <option value="Kimia">Kimia</option>
                    <option value="Organik">Organik</option>
                </select>
                <?php if($errors->has('jenis')): ?>
                  <span class="help-block"><?php echo e($errors->first('jenis')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('harga') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">HARGA PUPUK</label>
                <input type="text" class="form-control" name="harga"  placeholder="Masukkan Harga Pupuk(Rp)" value="<?php echo e(old('harga')); ?>">
                <?php if($errors->has('harga')): ?>
                  <span class="help-block"><?php echo e($errors->first('harga')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('jumlah_pupuk') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">JUMLAH PEMESANAN PUPUK</label>
                <input type="text" class="form-control" name="jumlah_pupuk"  placeholder="Masukkan Berat Pupuk yang Dipesan" value="<?php echo e(old('jumlah_pupuk')); ?>">
                <?php if($errors->has('jumlah_pupuk')): ?>
                  <span class="help-block"><?php echo e($errors->first('jumlah_pupuk')); ?></span>
                <?php endif; ?>
            </div>
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/Pupuk/index.blade.php ENDPATH**/ ?>