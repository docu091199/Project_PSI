

<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
        	<div class="row">
				<div class="col-md-12">
				<br>	
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title">Chart</h3>
								<div id="chartPupuk"></div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Daftar Pupuk</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										<button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
									</div>
								</div>
								<div class="panel-body no-padding">
									<table class="table table-striped">
										<thead>
											<tr>
												<td>No</td>
												<td>KODE</td>
												<td>NAMA</td>
												<td>JENIS</td>
												<td>HARGA</td>
											</tr>
                                        </thead>
										<tbody>
                                        <?php $__currentLoopData = $data_pupuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
											<tr>
												<td><?php echo e($result + $data_pupuk->firstitem()); ?></td>
												<td><?php echo e($hasil->pupuk_id); ?></a></td>
												<td><?php echo e($hasil->name); ?></a></td>
												<td><?php echo e($hasil->jenis); ?></td>
												<td> <?php echo e($hasil->harga); ?> /kg</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
						<div class = "col-md-6">
							<div class="panel">
								<div class="panel-heading">
								<h3 class="panel-title">Kelompok Tani</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										<button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
									</div>									
								</div>
								<div class="panel-body no-padding">
									<table class="table table-striped">
										<thead>
											<tr>
											<td>No</td>
											<td>ID</td>
											<td>NAMA</td>
											<td>KETUA</td>
											<td>ANGGOTA</td>
											</tr>
                                        </thead>
										<tbody>
                                        <?php $__currentLoopData = $data_keltan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
											<tr>
											<td><?php echo e($result + $data_keltan->firstitem()); ?></td>
											<td><?php echo e($hasil->keltan_id); ?></td>
											<td><?php echo e($hasil->name); ?></td>
											<td><?php echo e($hasil->leader); ?></td>
											<td><?php echo e($hasil->member); ?></td>
											</tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12">
				<br>	
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title">Chart</h3>
								<div id="chart"></div>
						</div>
        	</div>    
    	</div>
	</div>
</div>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script>
	Highcharts.chart('chartPupuk', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Laporan Data Pupuk Bersubsidi'
    },
    xAxis: {
        categories:<?php echo json_encode($categories); ?>,
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah Pupuk (kg)'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f} kg</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'Berat Pupuk yang Dipesan',
        data: <?php echo json_encode($berat); ?>



    }]
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/Dashboards/index.blade.php ENDPATH**/ ?>