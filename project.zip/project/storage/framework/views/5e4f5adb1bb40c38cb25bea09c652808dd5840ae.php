

<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">UBAH DATA RDKK</p></b></h1>
                        </div>
                        <div class="panel-body">
                            <?php if(Session::has('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(Session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                            <form action = "#" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group <?php echo e($errors->has('nama_kelompok') ? 'has-error' : ''); ?>">
                                    <label for="nama_kelompok">Nama Kelompok </label>
                                    <input type="text" class="form-control" name="nama_kelompok"  value="<?php echo e($rdkk->nama_kelompok); ?>">
                                <?php if($errors->has('nama_kelompok')): ?>
                                    <span class="help-block"><?php echo e($errors->first('nama_kelompok')); ?></span>
                                <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('alamat') ? 'has-error' : ''); ?>">
                                    <label for="alamat">Alamat</label>
                                    <input type="text" class="form-control" name="alamat"  value="<?php echo e($rdkk->alamat); ?>">
                                <?php if($errors->has('alamat')): ?>
                                    <span class="help-block"><?php echo e($errors->first('alamat')); ?></span>
                                <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('nama_pengecer') ? 'has-error' : ''); ?>">
                                    <label for="nama_pengecer">Nama Pengecer</label>
                                    <select name="jenis_kelamin" class="form-control" id="nama_pengecer">
                                        <option>select...</option>
                                        <?php $__currentLoopData = $pengecer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($rdkk->nama_pengecer); ?>"><?php echo e($hasil->nama_pengecer); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php if($errors->has('nama_pengecer')): ?>
                                    <span class="help-block"><?php echo e($errors->first('nama_pengecer')); ?></span>
                                <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('luas_tanah') ? 'has-error' : ''); ?>">
                                    <label for="luas_tanah">Luas Tanah</label>
                                    <input type="text" class="form-control" name="luas_tanah"  placeholder="Masukkan Luas Tanah" value="<?php echo e($rdkk->luas_tanah); ?>">
                                <?php if($errors->has('luas_tanah')): ?>
                                    <span class="help-block"><?php echo e($errors->first('luas_tanah')); ?></span>
                                <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('jumlah_pupuk') ? 'has-error' : ''); ?> ">
                                    <label for="jumlah_pupuk">Jumlah Pupuk</label>
                                    <input type="text" name="avatar" class="form-control"  value="<?php echo e($rdkk->jumlah_pupuk); ?>">
                                <?php if($errors->has('jumlah_pupuk')): ?>
                                    <span class="help-block"><?php echo e($errors->first('jumlah_pupuk')); ?></span>
                                <?php endif; ?>
                                </div>
                                <button type="submit" class="btn btn-warning btn-sm">Update</button>
                            </form>
                        </div>
                    </div>
                </div>			       
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/Rdkk_Ketua/edit.blade.php ENDPATH**/ ?>