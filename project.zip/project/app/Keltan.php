<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Keltan extends Model
{
   
    protected $table = 'keltan';
    protected $fillable = ['keltan_id','name','leader','member','birth','wilayah','avatar','users_id'];

    public function getAvatar(){
        if(!$this->avatar){
            return asset('images/default.png');
        }

        return asset('images/'.$this->avatar);
    }
    use SoftDeletes;
}
