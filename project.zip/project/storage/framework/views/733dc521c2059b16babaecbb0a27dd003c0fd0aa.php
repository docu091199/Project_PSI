

<?php $__env->startSection('content'); ?>
<div class="main">
  <div class="main-container">
    <div class = "container-fluid">
      <div class = "row">
      <br>
        <div class = "col-md-12">
          <div class="panel">
				    <div class="panel-heading">
              <h2 class="panel-title"><b><p class="text-center">Daftar Pengajuan</p></b></h2>
                <div class="right">
                <?php if(auth()->user()->role=='kelompok'): ?>
                  <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>  
                <?php endif; ?>
                </div>
						</div>
						<div class="panel-body">
            <?php if(Session::has('sukses')): ?>
              <div class="alert alert-success" role="alert">
                <?php echo e(Session('sukses')); ?>

              </div>
            <?php endif; ?>             
						<table class="table table-hover">
							<thead>
								<tr>
                  <td>No</td>
                  <td>Nama Kelompok</td>
                  <td>Alamat</td>
                  <td>Nama Pengecer</td>
                
                  <td>Status</td>
                  <td>AKSI</td>
								</tr>
						  </thead>
              <tbody>
                <?php $__currentLoopData = $rdkk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($result + 1); ?></td>
                  <td><?php echo e($hasil->nama_kelompok); ?></td>
                  <td><?php echo e($hasil->alamat); ?></td>
                  <td><?php echo e($hasil->nama_pengecer); ?></td>
                
                  <td><?php echo e($hasil->status_dinper); ?></td>
                  <td><a href="<?php echo e(route('Pengajuan-rdkk.show',$hasil->id)); ?>" class="badge badge-infor"><i class="lnr lnr-eye"></i></a>
                     
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
						  </tbody>
						</table>
   
					</div>
				</div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><b>Formulir Pengajuan Rencana Definitif Kebutuhan Kelompok</b></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "<?php echo e(route('Pengajuan-rdkk.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('nama_kelompok') ? 'has-error' : ''); ?>">
                <label for="nama_kelompok">Nama Kelompok</label>
                <input type="text" class="form-control <?php $__errorArgs = ['nama_kelompok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_kelompok"  placeholder="Masukkan Nama Kelompok" value="<?php echo e(old('nama_kelompok')); ?>" >
                <?php if($errors->has('nama_kelompok')): ?>
                  <span class="help-block"><?php echo e($errors->first('nama_kelompok')); ?></span>
                <?php endif; ?>
    
            </div>
            <div class="form-group <?php echo e($errors->has('alamat') ? 'has-error' : ''); ?>">
                <label for="alamat">Alamat Kelompok</label>
                <input type="text" class="form-control" name="alamat"  placeholder="Masukkan Alamat Kelompok" value="<?php echo e(old('alamat')); ?>">
                <?php if($errors->has('alamat')): ?>
                  <span class="help-block"><?php echo e($errors->first('alamat')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('nama_pengecer') ? 'has-error' : ''); ?>">
                <label for="nama_pengecer">Nama Pengecer</label>
                <select name="nama_pengecer" class="form-control" id="nama_pengecer">
                    <option placeholder>Select...</option>
                    <?php $__currentLoopData = $pengecer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasil => $lop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option ><?php echo e($lop->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('nama_pengecer')): ?>
                  <span class="help-block"><?php echo e($errors->first('nama_pengecer')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('luas_tanah') ? 'has-error' : ''); ?>">
                <label for="luas_tanah">Luas Tanah</label>
                <input type="text" class="form-control <?php $__errorArgs = ['luas_tanah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="luas_tanah"  placeholder="Masukkan Luas Tanah" value="<?php echo e(old('luas_tanah')); ?>">
                <?php if($errors->has('luas_tanah')): ?>
                  <span class="help-block"><?php echo e($errors->first('luas_tanah')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('nama_pupuk') ? 'has-error' : ''); ?>">
                <label for="nama_pupuk">Nama Pupuk</label>
                <input type="text" class="form-control" name="nama_pupuk"  placeholder="Masukkan Nama Pupuk" value="<?php echo e(old('nama_pupuk')); ?>">
                <?php if($errors->has('nama_pupuk')): ?>
                  <span class="help-block"><?php echo e($errors->first('nama_pupuk')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('jumlah_pupuk') ? 'has-error' : ''); ?>">
                <label for="jumlah_pupuk">Jumlah Pupuk</label>
                <input type="text" class="form-control" name="jumlah_pupuk"  placeholder="Masukkan Jumlah Pupuk" value="<?php echo e(old('jumlah_pupuk')); ?>">
                <?php if($errors->has('jumlah_pupuk')): ?>
                  <span class="help-block"><?php echo e($errors->first('jumlah_pupuk')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('waktu_penggunaan') ? 'has-error' : ''); ?>">
                <label for="waktu_penggunaan">Waktu Penggunaan</label>
                <input type="date" class="form-control" name="waktu_penggunaan"  value="<?php echo e(old('waktu_penggunaan')); ?>">
                <?php if($errors->has('waktu_penggunaan')): ?>
                  <span class="help-block"><?php echo e($errors->first('waktu_penggunaan')); ?></span>
                <?php endif; ?>
            </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

 


<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/Rdkk_Ketua/index.blade.php ENDPATH**/ ?>