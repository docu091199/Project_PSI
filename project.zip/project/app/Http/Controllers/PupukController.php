<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\pupuk;

class PupukController extends Controller
{
    public function index()
    {
       $data_pupuk=pupuk::paginate(10);
       return view('DinasPertanian.Pupuk.index',['data_pupuk'=> $data_pupuk]);
    }

    public function create(Request $request)
    {
        $this->validate($request,[
            'pupuk_id'=>'required|unique:pupuk,pupuk_id|min:6',
            'name'=>'required',
            'jenis'=>'required',
            'harga'=>'required|numeric',
            'jumlah_pupuk'=>'required|numeric'
        ]);

        $pupuk = pupuk::create($request->all());
        return redirect('/Pupuk')->with('sukses','Data Pupuk Bersubsidi Berhasil diinput');
    }

    public function edit($id)
    {
        $pupuk = pupuk::find($id);
        return view('DinasPertanian.Pupuk.edit',['pupuk' => $pupuk]);  

    }

    public function update(Request $request, $id){
        $this->validate($request,[
            'pupuk_id'=>'required|min:6',
            'name'=>'required',
            'jenis'=>'required',
            'harga'=>'required|numeric',
            'jumlah_pupuk'=>'required|numeric'
        ]);

        $pupuk = pupuk::find($id);
        $pupuk->update($request->all());
        
        return redirect('/Pupuk')->with('sukses','Data Pupuk Bersubsidi Berhasil diubah');
    }

    function delete($id)
    {
        $pupuk = pupuk::find($id);
        $pupuk->delete($pupuk);
        return redirect('/Pupuk')->with('sukses','Data Pupuk Bersubsidi Berhasil Dihapus');
    }
}
