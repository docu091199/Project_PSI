<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Keltan;
use App\User;

class KeltanController extends Controller
{
     
    public function index(Request $request)
    {
        if($request->has('cari')){
            $data_keltan=keltan::where('name','LIKE','%'.$request->cari.'%')->get();
        }
        else{
            $data_keltan = keltan::paginate(10);
        }
        return view('DinasPertanian.Keltan.index',['data_keltan' => $data_keltan]);
    }

    public function create(Request $request)
    {
        $this->validate($request,[
            'keltan_id'=>'required|unique:keltan,keltan_id|min:6',
            'name'=>'required|min:5',
            'leader'=>'required|min:5',
            'member'=>'required|numeric',
            'birth'=>'required',
            'wilayah'=>'required|numeric',
            'email'=>'required|unique:users,email',
            'avatar'=>'mimes:jpg,png,jpeg'
        ]);
        
        //insert->user_table
        $user = new user;
        $user->role = 'kelompok';
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = bcrypt('rahasia');
        $user->save();

        //insert->keltan_table
        $request->request->add(['users_id'=> $user->id]);
        $keltan = keltan::create($request->all());
        if($request->hasfile('avatar')){
            $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName());
            $keltan->avatar=$request->file('avatar')->getClientOriginalName();
            $keltan->save();
        }

        return redirect('/KelompokTani')->with('sukses','Data Berhasil diinput');
    }

    
    public function store(Request $request)
    {
        //
    }

   
    public function show($id)
    {
        //
    }

  
    public function edit($id)
    {
        $keltan = keltan::find($id);
        return view('DinasPertanian.Keltan.edit',['keltan' => $keltan]);   
    }

    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'keltan_id'=>'required|min:6',
            'name'=>'required|min:5',
            'leader'=>'required|min:5',
            'member'=>'required|numeric',
            'birth'=>'required',
            'wilayah'=>'required|numeric',
            'avatar'=>'mimes:jpg,png,jpeg'
        ]);

        $keltan = keltan::find($id);
        $keltan -> update($request->all());
        if($request->hasfile('avatar')){
            $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName());
            $keltan->avatar=$request->file('avatar')->getClientOriginalName();
            $keltan->save();
        }
        return redirect('/KelompokTani')->with('sukses','Data berhasil diubah');
      
    }

    public function delete($id)
    {
        $keltan = keltan::find($id);
        $keltan->delete($keltan);
        return redirect('/KelompokTani')->with('sukses','Kelompok Tani Berhasil Di non aktifkan (Silahkan Cek Pada Trash Kelompok Tani)');
    }
   
    public function profile($id){
        $keltan = keltan::find($id);
        return view('DinasPertanian.Keltan.profile',['keltan' => $keltan]);
    }
    public function tampil_hapus(Request $request){
        $data_keltan = keltan::onlyTrashed()->paginate(10);
        return view('DinasPertanian.Keltan.nonaktif',['data_keltan'=>$data_keltan]);
    }
    public function restore($id){
        $keltan = keltan::withTrashed()->where('id', $id)->first();
        $keltan->restore();
        return redirect()->back()->with('sukses','Kelompok Tani Aktif Kembali(Silahkan Cek Pada List Kelompok Tani)');
    }
    public function kill($id){
        $keltan = keltan::withTrashed()->where('id', $id)->first();
        $keltan->forceDelete();

        return redirect()->back()->with('sukses','Kelompok Tani Berhasil Dihapus');
    }
}
