

<?php $__env->startSection('content'); ?>
<div class="main">
      <div class="main-container">
          <div class = "container-fluid">
            <div class = "row">
              <div class = "col-md-12">
              <br>
              <div class="panel">
								<div class="panel-heading">
                <h2 class="panel-title"><b><p class="text-center">DATA TRANSAKSI</p></b></h2>
                  <div class="right">
                    <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>
                </div>
								</div>
								<div class="panel-body">
                <?php if(Session::has('sukses')): ?>
                  <div class="alert alert-success" role="alert">
                 <?php echo e(Session('sukses')); ?>

                 </div>
                <?php endif; ?>
									<table class="table table-hover">
										<thead>
											<tr>
                        <td>No</td>
                        <td>ID</td>
                        <td>NAMA PENGIRIM</td>
                        <td>TANGGAL PENGIRIM</td>
                        <td>NAMA BANK</td>
                        <td>AKSI</td>
											</tr>
										</thead>
										<tbody>
                 <?php $__currentLoopData = $data_transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($result + $data_transaksi->firstitem()); ?></td>
                        <td><?php echo e($hasil->kode_transaksi); ?></td>
                        <td><?php echo e($hasil->nama_pengirim); ?></td>
                        <td><?php echo e($hasil->tanggal_pengiriman); ?></td>
                        <td><?php echo e($hasil->nama_bank); ?></td>
                        <td><a href="/Transaksi/<?php echo e($hasil->id); ?>/edit" class="btn btn-warning btn-sm"> Edit</a>
                        <a href="/Transaksi/<?php echo e($hasil->id); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin menghapus??')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
                <?php echo e($data_transaksi->links()); ?> 
								</div>
							</div>
            </div>
          </div>
        </div>
      </div>
  </div> 

  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Masukkan Data Transaksi</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "/Transaksi/create" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('kode_transaksi') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">KODE TRANSAKSI</label>
                <input type="text" class="form-control" name="kode_transaksi"  placeholder="Masukkan ID" value="<?php echo e(old('kode_transaksi')); ?>">
                <?php if($errors->has('kode_transaksi')): ?>
                  <span class="help-block"><?php echo e($errors->first('kode_transaksi')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('nama_pengirim') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Nama Pengirim</label>
                <input type="text" class="form-control" name="nama_pengirim" placeholder="Masukkan Nama Pengirim" value="<?php echo e(old('nama_pengirim')); ?>">
                <?php if($errors->has('nama_pengirim')): ?>
                  <span class="help-block"><?php echo e($errors->first('nama_pengirim')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('tanggal_pengiriman') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Tanggal pengiriman</label>
                <input type="date" class="form-control" name="tanggal_pengiriman"  value="<?php echo e(old('tanggal_pengiriman')); ?>">
                <?php if($errors->has('tanggal_pengiriman')): ?>
                  <span class="help-block"><?php echo e($errors->first('tanggal_pengiriman')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('nama_bank') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">NAMA BANK</label>
                <input type="text" class="form-control" name="nama_bank"  placeholder="Masukkan Nama Bank" value="<?php echo e(old('nama_bank')); ?>">
                <?php if($errors->has('nama_bank')): ?>
                  <span class="help-block"><?php echo e($errors->first('nama_bank')); ?></span>
                <?php endif; ?>
            </div>
            
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/DataTransaksi/index.blade.php ENDPATH**/ ?>