<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Pengecer extends Model
{
    protected $table='pengecer';
    protected $fillable=['pengecer_id','name','region','address','avatar'];
  
    public function getAvatar(){
        if(!$this->avatar){
            return asset('images/default.png');
        }

        return asset('images/'.$this->avatar);
    }
    use SoftDeletes;
}
