

<?php $__env->startSection('content'); ?>
<div class="main">
  <div class="main-container">
    <div class = "container-fluid">
      <div class = "row">
        <div class = "col-md-12">
          <div class="panel">
				    <div class="panel-heading">
              <h2 class="panel-title"><b><p class="text-center">Daftar Pengajuan Telah Disetujui</p></b></h2>
                <div class="right">
                <?php if(auth()->user()->role=='kelompok'): ?>
                  <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>  
                <?php endif; ?>
                </div>
						</div>
						<div class="panel-body">
            <?php if(Session::has('sukses')): ?>
              <div class="alert alert-success" role="alert">
                <?php echo e(Session('sukses')); ?>

              </div>
            <?php endif; ?>             
						<table class="table table-hover">
							<thead>
								<tr>
                  <td>No</td>
                  <td>Nama Kelompok</td>
                  <td>Alamat</td>
                  <td>Nama Pengecer</td>
                  <td>Status</td>
         
                  <td>AKSI</td>
								</tr>
						  </thead>
              <tbody>
                <?php $__currentLoopData = $rdkk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($result + 1); ?></td>
                  <td><?php echo e($hasil->nama_kelompok); ?></td>
                  <td><?php echo e($hasil->alamat); ?></td>
                  <td><?php echo e($hasil->nama_pengecer); ?></td>
                  <td><?php echo e($hasil->status_dinper); ?></td>
                  <td><a href="<?php echo e(route('Pengajuan-rdkk.show',$hasil->id)); ?>" class="badge badge-infor"><i class="lnr lnr-eye"></i></a>
                     
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
						  </tbody>
						</table>
   
					</div>
				</div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/Rdkk_Ketua/list_setuju.blade.php ENDPATH**/ ?>