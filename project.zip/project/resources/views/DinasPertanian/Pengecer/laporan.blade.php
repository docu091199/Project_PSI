@extends('Layouts.master')

@section('content')
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
        	<div class="row">
                <div class="col-md-7">
                <br>
                    <div class="panel">
                        <div class="panel-heading">
                                <div id="chartPupuk"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                <br>
                    <div class="panel">
                        <div class="panel-heading">  
                                <div id="chart"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title">Pupuk Yang Terjual</h3>
                            <div class="panel-body no-padding">
									<table class="table table-striped">
										<thead>
											<tr>
												<td>No</td>
												<td>Nama Pemesan</td>
												<td>Nama Pengecer</td>
												<td>Pupuk</td>
												<td>Jumlah Pupuk</td>
											</tr>
                                        </thead>
										<tbody>
                                        @foreach($rdkk as $result => $hasil)    
											<tr>
												<td>{{$result + $rdkk->firstitem()}}</td>
												<td>{{$hasil->nama_kelompok}}</a></td>
												<td>{{$hasil->nama_pengecer}}</a></td>
												<td>{{$hasil->nama_pupuk}}</td>
												<td>{{$hasil->jumlah_pupuk}} kg</td>
                                            </tr>
                                        @endforeach
										</tbody>
									</table>
								</div>
                        </div>
                    </div>    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('footer')
<script src="https://code.highcharts.com/highcharts.js"></script>
<script>
	Highcharts.chart('chartPupuk', {
    chart: {
        type: 'area'
    },
    title: {
        text: 'Rekapitulasi Penjualan'
    },
    xAxis: {
        categories:{!!json_encode($categories)!!},
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah Pupuk (kg)'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f} kg</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'Berat Pupuk yang Terjual',
        data: {!!json_encode($berat)!!}
    }]
});
</script>
<script>
	Highcharts.chart('chart', {
    chart: {
        plotBackgroundColor:null,
        plotBorderWidth:null,
        type: 'pie'
    },
    title: {
        text: 'Rekapitulasi Penjualan'
    },
    xAxis: {
        categories:{!!json_encode($categories)!!},
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Jumlah Pupuk (kg)'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f} kg</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'Berat Pupuk yang Terjual',
        data: {!!json_encode($berat)!!}
    }]
});

</script>
@endsection