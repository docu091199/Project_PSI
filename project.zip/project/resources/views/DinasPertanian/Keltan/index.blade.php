@extends('Layouts.master')

@section('content')
  <div class="main">
      <div class="main-container">
          <div class = "container-fluid">
            <div class = "row">
              <div class = "col-md-12">
              <br>
              <div class="panel">
								<div class="panel-heading">
                <h2 class="panel-title"><b><p class="text-center">DATA KELOMPOK TANI</p></b></h2>
                  <div class="right">
                    <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>
                </div>
								</div>
								<div class="panel-body">
                @if(Session::has('sukses'))
                  <div class="alert alert-success" role="alert">
                 {{Session('sukses') }}
                 </div>
                @endif
									<table class="table table-hover">
										<thead>
											<tr>
                        <td>No</td>
                        <td>ID</td>
                        <td>NAMA KELOMPOK</td>
                        <td>NAMA KETUA</td>
                        <td>JUMLAH ANGGOTA</td>
                        <td>AKSI</td>
											</tr>
										</thead>
										<tbody>
                 @foreach($data_keltan as $result => $hasil)
                    <tr>
                        <td>{{$result + $data_keltan->firstitem()}}</td>
                        <td><a href="/KelompokTani/{{$hasil->id}}/profile">{{$hasil->keltan_id}}</a></td>
                        <td><a href="/KelompokTani/{{$hasil->id}}/profile">{{$hasil->name}}</a></td>
                        <td>{{$hasil->leader}}</td>
                        <td>{{$hasil->member}}</td>
                        <td><a href="/KelompokTani/{{$hasil->id}}/edit" class="btn btn-warning btn-sm"> Edit</a>
                        <a href="/KelompokTani/{{$hasil->id}}/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin mengganti status??')">Non Aktif</a>
                        </td>
                    </tr>
                @endforeach
										</tbody>
									</table>
                {{$data_keltan->links()}} 
								</div>
							</div>
            </div>
          </div>
        </div>
      </div>
  </div> 

  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Masukkan Data Kelompok Tani</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "/KelompokTani/create" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group {{$errors->has('keltan_id') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">ID Kelompok Tani</label>
                <input type="text" class="form-control" name="keltan_id"  placeholder="Masukkan ID" value="{{old('keltan_id')}}">
                @if($errors->has('keltan_id'))
                  <span class="help-block">{{$errors->first('keltan_id')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('name') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Nama Kelompok</label>
                <input type="text" class="form-control" name="name" placeholder="Masukkan Nama Kelompok" value="{{old('name')}}">
                @if($errors->has('name'))
                  <span class="help-block">{{$errors->first('name')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('leader') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Nama Ketua</label>
                <input type="text" class="form-control" name="leader"  placeholder="Masukkan Nama Ketua" value="{{old('leader')}}">
                @if($errors->has('leader'))
                  <span class="help-block">{{$errors->first('leader')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('birth') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Tanggal dibentuk</label>
                <input type="date" class="form-control" name="birth"  value="{{old('birth')}}">
                @if($errors->has('birth'))
                  <span class="help-block">{{$errors->first('birth')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('wilayah') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Luas Wilayah</label>
                <input type="text" class="form-control" name="wilayah"  placeholder="Masukkan Jumlah Luas Wilayah (dalam satuan Hh)" value="{{old('wilayah')}}">
                @if($errors->has('wilayah'))
                  <span class="help-block">{{$errors->first('wilayah')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('email') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Email</label>
                <input type="email" class="form-control" name="email"  placeholder="Masukkan Email" value="{{old('email')}}">
                @if($errors->has('email'))
                  <span class="help-block">{{$errors->first('email')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('member') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Jumlah Anggota</label>
                <input type="text" class="form-control" name="member"  placeholder="Masukkan Jumlah Anggota" value="{{old('member')}}">
                @if($errors->has('member'))
                  <span class="help-block">{{$errors->first('member')}}</span>
                @endif
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Avatar</label>
                  <input type="file" name="avatar" class="form-control"  value="{{old('avatar')}}">
            </div>
            <div class="form-group form-check {{$errors->has('avatar') ? 'has-error' : ''}}">
                @if($errors->has('avatar'))
                  <span class="help-block">{{$errors->first('avatar')}}</span>
                @endif
            </div>
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>
@endsection
