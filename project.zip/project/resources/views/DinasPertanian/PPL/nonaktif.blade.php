@extends('Layouts.master')

@section('content')
<div class="main">
    <div class="main-container">
      <div class = "container-fluid">
         <div class = "row">
            <div class = "col-md-12">
            <br>
              <div class="panel">
			    <div class="panel-heading">
          <h2 class="panel-title"><b><p class="text-center">DATA PPL YANG SUDAH TIDAK BEROPERASI</p></b></h2>
				</div>
				<div class="panel-body">
                @if(Session::has('sukses'))
                <div class="alert alert-success" role="alert">
                 {{Session('sukses') }}
                </div>
                @endif
				<table class="table table-hover">
					<thead>
						<tr>
                <td>No</td>
                <td>NIP</td>
                <td>NAMA PPL</td>
                <td>JENIS KELAMIN</td>
                <td>LOKASI KERJA</td>
                <td>AKSI</td>
						</tr>
					</thead>
					<tbody>
            @foreach($data_ppl as $result => $hasil)
            <tr>
              <td>{{$result + $data_ppl->firstitem()}}</td>
              <td><a>{{$hasil->ppl_nip}}</a></td>
              <td><a>{{$hasil->ppl_name}}</a></td>
              <td>{{$hasil->jenis_kelamin}}</td>
              <td>{{$hasil->allocation_place}}</td>
              <td>
              <form action="/PPL/{{$hasil->id}}/kill" method="POST">
                <a href="/PPL/{{$hasil->id}}/aktif" class="btn btn-primary btn-sm">Aktif</a>
                @csrf
                @method('delete')
              <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin menghapus secara permanen??')">Delete</button>
              </form>
                </td>
              </tr>
              @endforeach
            </tbody>
				</table>
        {{$data_ppl->links()}}
			      </div>
		      </div>
        </div>
      </div>
    </div>
  </div>
</div> 

@endsection