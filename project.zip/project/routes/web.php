<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/login','AuthController@login')->name('login');
Route::post('/postlogin','AuthController@postlogin');
Route::get('/logout','AuthController@logout');

Route::group(['middleware' => ['auth','CheckRole:disper,ppl']],function(){
    Route::get('/dashboard','DashboardController@index');
    //KelompokTani
    Route::get('/KelompokTani','KeltanController@index');
    Route::post('/KelompokTani/create','KeltanController@create');
    Route::get('/KelompokTani/{id}/edit','KeltanController@edit');
    Route::get('/KelompokTani/{id}/delete', 'KeltanController@delete');
    Route::get('/KelompokTani/{id}/profile', 'KeltanController@profile');
    Route::get('/KelompokTani/nonaktif','KeltanController@tampil_hapus')->name('keltan.tampil_hapus');
    Route::get('/KelompokTani/{id}/aktif','KeltanController@restore')->name('keltan.aktif');
    Route::delete('/KelompokTani/{id}/kill','KeltanController@kill')->name('keltan.kill');
    Route::post('/KelompokTani/{id}/update','KeltanController@update');
    //PPL
    Route::get('/PPL','PplController@index');
    Route::post('/PPL/create','PplController@create');
    Route::get('/PPL/{id}/edit','PplController@edit');
    Route::post('/PPL/{id}/update','PplController@update');
    Route::get('/PPL/{id}/profile', 'PplController@profile');
    Route::get('/PPL/{id}/delete', 'PplController@delete');
    Route::get('/PPL/nonaktif','PplController@tampil_hapus')->name('ppl.tampil_hapus');
    Route::get('/PPL/{id}/aktif','PplController@restore')->name('ppl.aktif');
    Route::delete('/PPL/{id}/kill','PplController@kill')->name('ppl.kill');
    //Pengecer
    Route::get('/Pengecer','PengecerController@index');
    Route::post('/Pengecer/create','PengecerController@create');
    Route::get('/Pengecer/{id}/profile', 'PengecerController@profile');
    Route::get('/Pengecer/{id}/edit','PengecerController@edit');
    Route::post('/Pengecer/{id}/update','PengecerController@update');
    Route::get('/Pengecer/{id}/delete', 'PengecerController@delete');
    Route::get('/Pengecer/nonaktif','PengecerController@tampil_hapus')->name('pengecer.tampil_hapus');
    Route::get('/Pengecer/{id}/aktif','PengecerController@restore')->name('pengecer.aktif');
    Route::delete('/Pengecer/{id}/kill','PengecerController@kill')->name('pengecer.kill');
    //Pupuk
    Route::get('/Pupuk','PupukController@index');
    Route::post('/Pupuk/create','PupukController@create');
    Route::get('/Pupuk/{id}/edit','PupukController@edit');
    Route::post('/Pupuk/{id}/update','PupukController@update');
    Route::get('/Pupuk/{id}/delete', 'PupukController@delete');
    //RDKK
    Route::get('/RDKK','rdkkController@index');
    Route::post('/RDKK/create','rdkkController@create');

});
Route::group(['middleware'=>['auth','CheckRole:pengecer,disper']],function(){
    Route::get('/Pengecer/Laporan','LaporanController@index');
    //Transaksi
    Route::get('/Transaksi','TransaksiController@index');
    Route::post('/Transaksi/create','TransaksiController@create');
    Route::get('/Transaksi/{id}/edit','TransaksiController@edit');
    Route::post('/Transaksi/{id}/update','TransaksiController@update');
    Route::get('/Transaksi/{id}/delete', 'TransaksiController@delete');
});

Route::group(['middleware' => ['auth','CheckRole:disper,kelompok,ppl,pengecer']],function(){
    Route::get('/dashboard','DashboardController@index');
    //pengajuan RDKK
    Route::resource('/Pengajuan-rdkk','RdkkController');
    //ppl Approve and rejected
    Route::patch('/Pengajuan-rdkk/{id}/approve-ppl','RdkkController@approve_ppl');
    Route::patch('/Pengajuan-rdkk/{id}/rejected-ppl','RdkkController@rejected_ppl');
    Route::get('/List/Approve-ppl','RdkkController@list_approve');
    Route::get('/List/Rejected-ppl','RdkkController@list_rejected');
    Route::patch('/Pengajuan-rdkk/{id}/konfirmasi-pengecer','RdkkController@konfirmasi_pengecer');
    Route::get('/List/Konfirmasi-pengecer','RdkkController@list_konfirmasi');
    Route::patch('/Pengajuan-rdkk/{id}/dinas-setuju','RdkkController@setuju');
    Route::patch('Pengajuan-rdkk/{id}/dinas-tolak','RdkkController@tolak');
    Route::get('/List/Pengajuan-diterima','RdkkController@list_setuju');
    Route::get('/List/Pengajuan-ditolak','RdkkController@list_tolak');
});  
