

<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-container">
      <div class = "container-fluid">
         <div class = "row">
            <div class = "col-md-12">
              <div class="panel">
			    <div class="panel-heading">
          <h2 class="panel-title"><b><p class="text-center">DATA PENGECER YANG SUDAH TIDAK BEROPERASI</p></b></h2>
				</div>
				<div class="panel-body">
                <?php if(Session::has('sukses')): ?>
                <div class="alert alert-success" role="alert">
                 <?php echo e(Session('sukses')); ?>

                </div>
                <?php endif; ?>
				<table class="table table-hover">
					<thead>
						<tr>
                            <td>No</td>
                            <td>ID</td>
                            <td>NAMA PENGECER</td>
                            <td>REGION</td>
                            <td>ALAMAT</td>
                            <td>AKSI</td>
						</tr>
					</thead>
					<tbody>
            <?php $__currentLoopData = $data_pengecer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($result + $data_pengecer->firstitem()); ?></td>
              <td><a><?php echo e($hasil->pengecer_id); ?></a></td>
              <td><a><?php echo e($hasil->name); ?></a></td>
              <td><?php echo e($hasil->region); ?></td>
              <td><?php echo e($hasil->address); ?></td>
              <td>
              <form action="/Pengecer/<?php echo e($hasil->id); ?>/kill" method="POST">
                <a href="/Pengecer/<?php echo e($hasil->id); ?>/aktif" class="btn btn-primary btn-sm">Aktif</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
              <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin menghapus secara permanen??')">Delete</button>
              </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
				</table>
        <?php echo e($data_pengecer->links()); ?>

			      </div>
		      </div>
        </div>
      </div>
    </div>
  </div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/Pengecer/nonaktif.blade.php ENDPATH**/ ?>