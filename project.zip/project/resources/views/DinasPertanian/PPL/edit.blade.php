@extends('Layouts.master')

@section('content')
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                <br>
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">UBAH DATA PPL</p></b></h1>
                        </div>
                        <div class="panel-body">
                            @if(Session::has('sukses'))
                                <div class="alert alert-success" role="alert">
                                {{Session('sukses') }}
                                </div>
                            @endif
                            <form action = "/PPL/{{$ppl->id}}/update" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group {{$errors->has('ppl_nip') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">NIP </label>
                                    <input type="text" class="form-control" name="ppl_nip"  placeholder="Masukkan NIP PPL" value="{{$ppl->ppl_nip}}">
                                @if($errors->has('ppl_nip'))
                                    <span class="help-block">{{$errors->first('ppl_nip')}}</span>
                                @endif
                                </div>
                                <div class="form-group {{$errors->has('ppl_name') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">NAMA PPL</label>
                                    <input type="text" class="form-control" name="ppl_name"  placeholder="Masukkan Nama PPL" value="{{$ppl->ppl_name}}">
                                @if($errors->has('ppl_name'))
                                    <span class="help-block">{{$errors->first('ppl_name')}}</span>
                                @endif
                                </div>
                                <div class="form-group {{$errors->has('jenis_kelamin') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">PILIH JENIS KELAMIN</label>
                                    <select name="jenis_kelamin" class="form-control" id="exampleformControlSelect1">
                                        <option>select...</option>
                                        <option value="L">Laki-Laki</option>
                                        <option value="P">Perempuan</option>
                                    </select>
                                @if($errors->has('jenis_kelamin'))
                                    <span class="help-block">{{$errors->first('jenis_kelamin')}}</span>
                                @endif
                                </div>
                                <div class="form-group {{$errors->has('allocation_place') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">LOKASI KERJA</label>
                                    <input type="text" class="form-control" name="allocation_place"  placeholder="Masukkan Lokasi Kerja (Kecamatan)" value="{{$ppl->allocation_place}}">
                                @if($errors->has('allocation_place'))
                                    <span class="help-block">{{$errors->first('allocation_place')}}</span>
                                @endif
                                </div>
                                <div class="form-group {{$errors->has('avatar') ? 'has-error' : ''}} ">
                                    <label for="exampleInputEmail1">Avatar</label>
                                    <input type="file" name="avatar" class="form-control"  value="{{$ppl->avatar}}">
                                @if($errors->has('avatar'))
                                    <span class="help-block">{{$errors->first('avatar')}}</span>
                                @endif
                                </div>
                                <button type="submit" class="btn btn-warning btn-sm">Update</button>
                            </form>
                        </div>
                    </div>
                </div>			       
            </div>
        </div>
    </div>
</div>
@endsection