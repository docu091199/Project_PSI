<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Rdkk;
use App\Pengecer;
use App\Keltan;
use App\pupuk;
use App\User;
use Auth;
use Route;
use DB;

class RdkkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $user = auth()->user()->role;
        $pengecer= Pengecer::paginate(10);
        

        if($user=="kelompok"){
        $id = auth()->user()->id;
        $rdkk= DB::select(DB::raw("SELECT * FROM `rdkks` WHERE `user_id` = :id AND `status_dinper`= 'Menunggu'" ),array('id'=>$id));
        return view('Rdkk_Ketua.index',compact('rdkk','pengecer'));

        }elseif($user=="ppl"){
        $rdkk= DB::select(DB::raw("SELECT * FROM `rdkks` WHERE  `status_ppl`='Menunggu'"  )); 
        return view('Rdkk_Ketua.index',compact('rdkk','pengecer'));

        }elseif($user=="pengecer"){
        $nama = auth()->user()->name;
        $rdkk= DB::select(DB::raw("SELECT * FROM `rdkks` WHERE `nama_pengecer`=:nama  AND `status_ppl`='Approve' AND `status_pengecer` = 'Menunggu' "),array('nama' => $nama)); 
        return view('Rdkk_Ketua.index',compact('rdkk','pengecer'));

        }else{
        $rdkk= DB::select(DB::raw("SELECT * FROM `rdkks` WHERE  `status_dinper`='Menunggu' AND  `status_pengecer`='Konfirmasi' "  )); 
        return view('Rdkk_Ketua.index',compact('rdkk','pengecer'));
    }
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'nama_kelompok'=>'required',
            'alamat'=>'required',
            'nama_pengecer'=>'required',
           'nama_pupuk'=>'required',
            'luas_tanah'=>'required',
            'jumlah_pupuk'=>'required',
            'waktu_penggunaan'=>'required'
        ]);

        Rdkk::create([
            'user_id' => (auth()->user()->id),
            'nama_kelompok'=>$request->nama_kelompok,
            'alamat'=>$request->alamat,
            'nama_pengecer'=>$request->nama_pengecer,
            'luas_tanah'=>$request->luas_tanah,
            'nama_pupuk'=>$request->nama_pupuk,
            'jumlah_pupuk'=>$request->jumlah_pupuk,
            'waktu_penggunaan'=>$request->waktu_penggunaan,
            'status_dinper'=>'Menunggu',
            'status_ppl'=>'Menunggu',
            'status_pengecer'=>'Menunggu'
        ]);  
        return redirect('/Pengajuan-rdkk')->with('success','data berhasil dibuat');


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $rdkk = Rdkk::find($id);
        return view('Rdkk_Ketua.show',compact('rdkk'));
    

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pengecer=Pengecer::paginate();
        $rdkk=Rdkk::paginate();
        return view('Rdkk_Ketua.edit', Compact('rdkk','pengecer'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Rdkk::destroy($id);
        return redirect('/Pengajuan-rdkk')->with('success','data berasil dihapus');
    }

    public function approve_ppl($id){
        $rdkk = Rdkk::find($id);
        $rdkk->status_ppl='Approve';
        $rdkk->save();
        return redirect()->back()->with('success','Data Telah Approve');
    }

    public function rejected_ppl($id){
        $rdkk = Rdkk::find($id);
        $rdkk->status_ppl='Rejected';
        $rdkk->save();
        return redirect()->back()->with('success','Rejected Berhasil');
    }

    public function list_approve(){
        $rdkk = DB::select(DB::raw("SELECT * FROM `rdkks` WHERE  `status_ppl`='Approve'")); 
        return view('Rdkk_Ketua.list_approve',compact('rdkk'));
    }

    public function list_rejected(){
        $rdkk = DB::select(DB::raw("SELECT * FROM `rdkks` WHERE  `status_ppl`='Rejected'")); 
        return view('Rdkk_Ketua.list_rejected',compact('rdkk'));
    }

    public function konfirmasi_pengecer($id){
        $rdkk = Rdkk::find($id);
        $rdkk->status_pengecer='Konfirmasi';
        $rdkk->save();
        return redirect()->back()->with('success', 'Berhasil');
    }

    public function list_konfirmasi(){
        $rdkk = DB::select(DB::raw("SELECT * FROM `rdkks` WHERE  `status_pengecer`='Konfirmasi'")); 
        return view('Rdkk_Ketua.list_konfirmasi',compact('rdkk'));
    }

    public function setuju($id){
        $rdkk= Rdkk::find($id);
        $rdkk->status_dinper='Setuju';
        $rdkk->save();
        return redirect()->back()->with('success', 'Berhasil');
    }

    public function tolak($id){
        $rdkk= Rdkk::find($id);
        $rdkk->status_dinper='Tolak';
        $rdkk->save();
        return redirect()->back()->with('success', 'Berhasil');
    }

    public function list_setuju(){
        $rdkk = DB::select(DB::raw("SELECT * FROM `rdkks` WHERE  `status_dinper`='Setuju' AND  `status_pengecer`='Konfirmasi' ")); 
        return view('Rdkk_Ketua.list_setuju',compact('rdkk'));
        
    }

    public function list_tolak(){
        $rdkk = DB::select(DB::raw("SELECT * FROM `rdkks` WHERE  `status_dinper`='Tolak' AND  `status_pengecer`='Konfirmasi' ")); 
        return view('Rdkk_Ketua.list_tolak',compact('rdkk'));
        
    }


}
