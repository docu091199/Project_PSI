
@extends('Layouts.master')

@section('content')
<div class="main">
      <div class="main-container">
          <div class = "container-fluid">
            <div class = "row">
              <div class = "col-md-12">
              <br>
              <div class="panel">
				<div class="panel-heading">
					<h1 class="panel-title"><b><p class="text-center">UBAH DATA KELOMPOK TANI</p></b></h1>
				</div>
					<div class="panel-body">
                    @if(Session::has('sukses'))
                        <div class="alert alert-success" role="alert">
                         {{Session('sukses') }}
                        </div>
                    @endif
                    <form action = "/KelompokTani/{{$keltan->id}}/update" method="POST" enctype="multipart/form-data">
                       @csrf
                        <div class="form-group {{$errors->has('keltan_id') ? 'has-error' : ''}}">
                            <label for="exampleInputEmail1">ID Kelompok Tani</label>
                            <input type="text" class="form-control" name="keltan_id"  placeholder="Masukkan ID" value="{{$keltan->keltan_id}}">
                                @if($errors->has('keltan_id'))
                                <span class="help-block">{{$errors->first('keltan_id')}}</span>
                                @endif
                        </div>
                        <div class="form-group {{$errors->has('name') ? 'has-error' : ''}}">
                            <label for="exampleInputEmail1">Nama Kelompok</label>
                            <input type="text" class="form-control" name="name" placeholder="Masukkan Nama Kelompok" value="{{$keltan->name}}">
                                @if($errors->has('name'))
                                <span class="help-block">{{$errors->first('name')}}</span>
                                @endif
                        </div>
                        <div class="form-group {{$errors->has('leader') ? 'has-error' : ''}}">
                            <label for="exampleInputEmail1">Nama Ketua</label>
                            <input type="text" class="form-control" name="leader"  placeholder="Masukkan Nama Ketua" value="{{$keltan->leader}}">
                                @if($errors->has('leader'))
                                <span class="help-block">{{$errors->first('leader')}}</span>
                                @endif
                        </div>
                        <div class="form-group {{$errors->has('birth') ? 'has-error' : ''}}">
                            <label for="exampleInputEmail1">Tanggal dibentuk</label>
                            <input type="date" class="form-control" name="birth"  value="{{$keltan->birth}}">
                                @if($errors->has('birth'))
                                <span class="help-block">{{$errors->first('birth')}}</span>
                                @endif
                        </div>
                        <div class="form-group {{$errors->has('wilayah') ? 'has-error' : ''}}">
                            <label for="exampleInputEmail1">Luas Wilayah</label>
                            <input type="text" class="form-control" name="wilayah"  placeholder="Masukkan Jumlah Luas Wilayah (dalam satuan Hh)" value="{{$keltan->wilayah}}">
                                @if($errors->has('wilayah'))
                                <span class="help-block">{{$errors->first('wilayah')}}</span>
                                @endif
                        </div>
                        <div class="form-group {{$errors->has('member') ? 'has-error' : ''}}">
                            <label for="exampleInputEmail1">Jumlah Anggota</label>
                            <input type="text" class="form-control" name="member"  placeholder="Masukkan Jumlah Anggota" value="{{$keltan->member}}">
                            @if($errors->has('member'))
                            <span class="help-block">{{$errors->first('member')}}</span>
                            @endif
                        </div>
                        <div class="form-group {{$errors->has('avatar') ? 'has-error' : ''}}">
                            <label for="exampleInputEmail1">Avatar</label>
                            <input type="file" name="avatar" class="form-control"  value="{{$keltan->avatar}}">
                            @if($errors->has('avatar'))
                                <span class="help-block">{{$errors->first('avatar')}}</span>
                            @endif
                        </div>
                            <button type="submit" class="btn btn-warning btn-sm">Update</button>
                    </form>
					</div>
				</div>
              </div>
            </div>
        </div>                  
</div>

@endsection

