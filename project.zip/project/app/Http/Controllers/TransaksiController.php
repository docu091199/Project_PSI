<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\transaksi;

class TransaksiController extends Controller
{
    
    public function index()
    {
        $data_transaksi=transaksi::paginate(10);
        return view('DinasPertanian.DataTransaksi.index',['data_transaksi'=> $data_transaksi]);
    }
    public function create(Request $request)
    {
        $this->validate($request,[
            'kode_transaksi'=>'required|unique:transaksi,kode_transaksi|min:6',
            'nama_pengirim'=>'required',
            'tanggal_pengiriman'=>'required',
            'nama_bank'=>'required'
        ]);

        $transaksi = transaksi::create($request->all());
        return redirect('/Transaksi')->with('sukses','Data Transaksi Berhasil diinput');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $transaksi = transaksi::find($id);
        return view('DinasPertanian.DataTransaksi.edit',['transaksi' => $transaksi]);  
    }
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'kode_transaksi'=>'required',
            'nama_pengirim'=>'required',
            'tanggal_pengiriman'=>'required',
            'nama_bank'=>'required'
        ]);
        $transaksi = transaksi::find($id);
        $transaksi->update($request->all());
        
        return redirect('/Transaksi')->with('sukses','Data Transaksi Berhasil diubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    function delete($id)
    {
        $transaksi = transaksi::find($id);
        $transaksi->delete($transaksi);
        return redirect('/Transaksi')->with('sukses','Data Transaksi Berhasil Dihapus');
    }
}
