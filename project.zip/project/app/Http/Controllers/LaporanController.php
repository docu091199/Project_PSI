<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Rdkk;
use App\Keltan;
use App\pupuk;

class LaporanController extends Controller
{
    public function index()
    {
        $data_keltan = keltan::paginate(10);
        $data_pupuk = pupuk::paginate(10);
        $rdkk = rdkk::paginate(10);

        $categories=[];
        $berat=[];
        foreach($rdkk as $dp){
            $categories[] = $dp->nama_pupuk;
            $berat[] = $dp->jumlah_pupuk;
        }
        
        return view('DinasPertanian.Pengecer.laporan',['data_pupuk' => $data_pupuk,'categories' => $categories,'berat' => $berat, "data_keltan"=>$data_keltan,'rdkk'=>$rdkk]);
    }

    
}
