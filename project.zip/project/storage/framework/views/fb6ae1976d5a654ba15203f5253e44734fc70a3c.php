

<?php $__env->startSection('content'); ?>
<div class="main">
  <div class="main-container">
    <div class = "container-fluid">
      <div class = "row">
        <div class = "col-md-12">
        <br>
          <div class="panel">
				    <div class="panel-heading">
              <h2 class="panel-title"><b><p class="text-center">DATA PPL</p></b></h2>
                <div class="right">
                  <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>  
                </div>
						</div>
						<div class="panel-body">
            <?php if(Session::has('sukses')): ?>
              <div class="alert alert-success" role="alert">
                <?php echo e(Session('sukses')); ?>

              </div>
            <?php endif; ?>             
						<table class="table table-hover">
							<thead>
								<tr>
                  <td>No</td>
                  <td>NIP</td>
                  <td>NAMA PPL</td>
                  <td>JENIS KELAMIN</td>
                  <td>LOKASI KERJA</td>
                  <td>AKSI</td>
								</tr>
						  </thead>
              <tbody>
                <?php $__currentLoopData = $data_ppl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($result + $data_ppl->firstitem()); ?></td>
                  <td><a href="/PPL/<?php echo e($hasil->id); ?>/profile"><?php echo e($hasil->ppl_nip); ?></a></td>
                  <td><a href="/PPL/<?php echo e($hasil->id); ?>/profile"><?php echo e($hasil->ppl_name); ?></a></td>
                  <td><?php echo e($hasil->jenis_kelamin); ?></td>
                  <td><?php echo e($hasil->allocation_place); ?></td>
                  <td><a href="/PPL/<?php echo e($hasil->id); ?>/edit" class="btn btn-warning btn-sm"> Edit</a>
                      <a href="/PPL/<?php echo e($hasil->id); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin mengganti status??')">Non Aktif</a>
                  </td>
                </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
						  </tbody>
						</table>
          <?php echo e($data_ppl->links()); ?> 
					</div>
				</div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Masukkan Data PPL</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "/PPL/create" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('ppl_nip') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">NIP </label>
                <input type="text" class="form-control" name="ppl_nip"  placeholder="Masukkan NIP PPL" value="<?php echo e(old('ppl_nip')); ?>">
                <?php if($errors->has('ppl_nip')): ?>
                  <span class="help-block"><?php echo e($errors->first('ppl_nip')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('ppl_name') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">NAMA PPL</label>
                <input type="text" class="form-control" name="ppl_name"  placeholder="Masukkan Nama PPL" value="<?php echo e(old('ppl_name')); ?>">
                <?php if($errors->has('ppl_name')): ?>
                  <span class="help-block"><?php echo e($errors->first('ppl_name')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('jenis_kelamin') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">PILIH JENIS KELAMIN</label>
                <select name="jenis_kelamin" class="form-control" id="exampleformControlSelect1">
                    <option placeholder>select...</option>
                    <option value="L">Laki-Laki</option>
                    <option value="P">Perempuan</option>
                </select>
                <?php if($errors->has('jenis_kelamin')): ?>
                  <span class="help-block"><?php echo e($errors->first('jenis_kelamin')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('allocation_place') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">LOKASI KERJA</label>
                <input type="text" class="form-control" name="allocation_place"  placeholder="Masukkan Lokasi Kerja (Kecamatan)" value="<?php echo e(old('allocation_place')); ?>">
                <?php if($errors->has('allocation_place')): ?>
                  <span class="help-block"><?php echo e($errors->first('allocation_place')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">email</label>
                <input type="email" class="form-control" name="email"  placeholder="Masukkan Email" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                  <span class="help-block"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Avatar</label>
                  <input type="file" name="avatar" class="form-control"  value="<?php echo e(old('avatar')); ?>">
            </div>
            <div class="form-group form-check <?php echo e($errors->has('avatar') ? 'has-error' : ''); ?>">
                <?php if($errors->has('avatar')): ?>
                  <span class="help-block"><?php echo e($errors->first('avatar')); ?></span>
                <?php endif; ?>
            </div>
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

 


<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/PPL/index.blade.php ENDPATH**/ ?>