

<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                <br>
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">UBAH DATA PUPUK BERSUBSIDI</p></b></h1>
                        </div>
                        <div class="panel-body">
                            <?php if(Session::has('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(Session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                            <form action = "/Transaksi/<?php echo e($transaksi->id); ?>/update" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group <?php echo e($errors->has('kode_transaksi') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">KODE TRANSAKSI</label>
                <input type="text" class="form-control" name="kode_transaksi"  placeholder="Masukkan ID" value="<?php echo e($transaksi->kode_transaksi); ?>">
                <?php if($errors->has('kode_transaksi')): ?>
                  <span class="help-block"><?php echo e($errors->first('kode_transaksi')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('nama_pengirim') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Nama Pengirim</label>
                <input type="text" class="form-control" name="nama_pengirim" placeholder="Masukkan Nama Pengirim" value="<?php echo e($transaksi->nama_pengirim); ?>">
                <?php if($errors->has('nama_pengirim')): ?>
                  <span class="help-block"><?php echo e($errors->first('nama_pengirim')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('tanggal_pengiriman') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Tanggal pengiriman</label>
                <input type="date" class="form-control" name="tanggal_pengiriman"  value="<?php echo e($transaksi->tanggal_pengiriman); ?>">
                <?php if($errors->has('tanggal_pengiriman')): ?>
                  <span class="help-block"><?php echo e($errors->first('tanggal_pengiriman')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('nama_bank') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">NAMA BANK</label>
                <input type="text" class="form-control" name="nama_bank"  placeholder="Masukkan Nama Bank" value="<?php echo e($transaksi->nama_bank); ?>">
                <?php if($errors->has('nama_bank')): ?>
                  <span class="help-block"><?php echo e($errors->first('nama_bank')); ?></span>
                <?php endif; ?>
            </div>
                            <button type="submit" class="btn btn-warning">Update</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/DataTransaksi/edit.blade.php ENDPATH**/ ?>