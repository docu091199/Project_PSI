@extends('Layouts.master')

@section('content')
<div class="main">
      <div class="main-container">
          <div class = "container-fluid">
            <div class = "row">
              <div class = "col-md-12">
              <br>
              <div class="panel">
								<div class="panel-heading">
                <h2 class="panel-title"><b><p class="text-center">DATA TRANSAKSI</p></b></h2>
                  <div class="right">
                    <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>
                </div>
								</div>
								<div class="panel-body">
                @if(Session::has('sukses'))
                  <div class="alert alert-success" role="alert">
                 {{Session('sukses') }}
                 </div>
                @endif
									<table class="table table-hover">
										<thead>
											<tr>
                        <td>No</td>
                        <td>ID</td>
                        <td>NAMA PENGIRIM</td>
                        <td>TANGGAL PENGIRIM</td>
                        <td>NAMA BANK</td>
                        <td>AKSI</td>
											</tr>
										</thead>
										<tbody>
                 @foreach($data_transaksi as $result => $hasil)
                    <tr>
                        <td>{{$result + $data_transaksi->firstitem()}}</td>
                        <td>{{$hasil->kode_transaksi}}</td>
                        <td>{{$hasil->nama_pengirim}}</td>
                        <td>{{$hasil->tanggal_pengiriman}}</td>
                        <td>{{$hasil->nama_bank}}</td>
                        <td><a href="/Transaksi/{{$hasil->id}}/edit" class="btn btn-warning btn-sm"> Edit</a>
                        <a href="/Transaksi/{{$hasil->id}}/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin menghapus??')">Delete</a>
                        </td>
                    </tr>
                @endforeach
										</tbody>
									</table>
                {{$data_transaksi->links()}} 
								</div>
							</div>
            </div>
          </div>
        </div>
      </div>
  </div> 

  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Masukkan Data Transaksi</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "/Transaksi/create" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group {{$errors->has('kode_transaksi') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">KODE TRANSAKSI</label>
                <input type="text" class="form-control" name="kode_transaksi"  placeholder="Masukkan ID" value="{{old('kode_transaksi')}}">
                @if($errors->has('kode_transaksi'))
                  <span class="help-block">{{$errors->first('kode_transaksi')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('nama_pengirim') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Nama Pengirim</label>
                <input type="text" class="form-control" name="nama_pengirim" placeholder="Masukkan Nama Pengirim" value="{{old('nama_pengirim')}}">
                @if($errors->has('nama_pengirim'))
                  <span class="help-block">{{$errors->first('nama_pengirim')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('tanggal_pengiriman') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Tanggal pengiriman</label>
                <input type="date" class="form-control" name="tanggal_pengiriman"  value="{{old('tanggal_pengiriman')}}">
                @if($errors->has('tanggal_pengiriman'))
                  <span class="help-block">{{$errors->first('tanggal_pengiriman')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('nama_bank') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">NAMA BANK</label>
                <input type="text" class="form-control" name="nama_bank"  placeholder="Masukkan Nama Bank" value="{{old('nama_bank')}}">
                @if($errors->has('nama_bank'))
                  <span class="help-block">{{$errors->first('nama_bank')}}</span>
                @endif
            </div>
            
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>



@endsection