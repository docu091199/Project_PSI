<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Rdkk extends Model
{
    protected $table = 'rdkks';
    protected $fillable = ['user_id', 'nama_kelompok', 'alamat', 'nama_pengecer', 'luas_tanah','nama_pupuk','jumlah_pupuk','waktu_penggunaan','status_dinper','status_ppl','status_pengecer'];

    public function pupuk(){
        return $this->belongsTo(pupuk::class);
    }

}
