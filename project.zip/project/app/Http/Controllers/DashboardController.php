<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Keltan;
use App\pupuk;
use App\Rdkk;
class DashboardController extends Controller
{
   
    public function index()
    {
        $data_keltan = keltan::paginate(10);
        $data_pupuk = pupuk::paginate(10);
        $rdkk = rdkk::paginate(10);

        $categories=[];
        $berat=[];
        foreach($rdkk as $dp){
            $categories[] = $dp->nama_pupuk;
            $berat[] = $dp->jumlah_pupuk;
        }
        
        //dd($berat);
        // dd(json_encode($categories));
        return view('Dashboards.index',['data_pupuk' => $data_pupuk,'categories' => $categories,'berat' => $berat, "data_keltan"=>$data_keltan]);
    }
   
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
