@extends('Layouts.master')

@section('content')

<div class="main">
  <div class="main-container">
    <div class = "container-fluid">
      <div class = "row">
        <div class = "col-md-12">
          <br>
          <div class="panel">
					  <div class="panel-heading">
              <h2 class="panel-title"><b><p class="text-center">DATA PENGECER RESMI</p></b></h2>
                <div class="right">
                  <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>
                </div>
					  </div>
					  <div class="panel-body">
              @if(Session::has('sukses'))
              <div class="alert alert-success" role="alert">
              {{Session('sukses') }}
              </div>
              @endif
						    <table class="table table-hover">
								  <thead>
									  <tr>
                      <td>No</td>
                      <td>ID</td>
                      <td>NAMA PENGECER</td>
                      <td>REGION</td>
                      <td>ALAMAT</td>
                      <td>AKSI</td>
									</tr>
								</thead>
								<tbody>
                @foreach($data_pengecer as $result => $hasil)
                  <tr>
                    <td>{{$result + $data_pengecer->firstitem()}}</td>
                    <td><a href="/Pengecer/{{$hasil->id}}/profile">{{$hasil->pengecer_id}}</a></td>
                    <td><a href="/Pengecer/{{$hasil->id}}/profile">{{$hasil->name}}</a></td>
                    <td>{{$hasil->region}}</td>
                    <td>{{$hasil->address}}</td>
                    <td><a href="/Pengecer/{{$hasil->id}}/edit" class="btn btn-warning btn-sm"> Edit</a>
                        <a href="/Pengecer/{{$hasil->id}}/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin mengganti status??')">Non Aktif</a>
                    </td>
                  </tr>
                @endforeach
								</tbody>
						    </table>
                {{$data_pengecer->links()}} 
					  </div>
          </div>
        </div>
      </div>
    </div>
  </div>  
</div> 
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Masukkan Data Pengecer Resmi</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "/Pengecer/create" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group {{$errors->has('pengecer_id') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">ID Pengecer</label>
                <input type="text" class="form-control" name="pengecer_id"  placeholder="Masukkan ID" value="{{old('pengecer_id')}}">
                @if($errors->has('pengecer_id'))
                  <span class="help-block">{{$errors->first('pengecer_id')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('name') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Nama Pengecer</label>
                <input type="text" class="form-control" name="name" placeholder="Masukkan Nama Pengecer (Toko Resmi)" value="{{old('name')}}">
                @if($errors->has('name'))
                  <span class="help-block">{{$errors->first('name')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('region') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Region</label>
                <input type="text" class="form-control" name="region"  placeholder="Masukkan Region" value="{{old('region')}}">
                @if($errors->has('region'))
                  <span class="help-block">{{$errors->first('region')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('address') ? 'has-error' : ''}}">
                <label for="exampleInputTextarea1">Alamat</label>
                <textarea type="text" class="form-control" name="address"  placeholder="Masukkan Alamat" >{{old('address')}}</textarea>
                @if($errors->has('address'))
                  <span class="help-block">{{$errors->first('address')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('email') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Email</label>
                <input type="email" class="form-control" name="email"  placeholder="Masukkan Email" value="{{old('email')}}">
                @if($errors->has('email'))
                  <span class="help-block">{{$errors->first('email')}}</span>
                @endif
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Avatar</label>
              <input type="file" name="avatar" class="form-control"  value="{{old('avatar')}}">
            </div>
            <div class="form-group form-check {{$errors->has('avatar') ? 'has-error' : ''}}">
                @if($errors->has('avatar'))
                  <span class="help-block">{{$errors->first('avatar')}}</span>
                @endif
            </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>

@endsection