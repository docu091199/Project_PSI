<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\ppl;
use App\User;

class PplController extends Controller
{
    
    public function index()
    {
       $data_ppl=ppl::paginate(10);
       return view('DinasPertanian.PPL.index',['data_ppl'=> $data_ppl]);
    }

    
    public function create(Request $request)
    {
        $this->validate($request,[
            'ppl_nip'=>'required|unique:ppl,ppl_nip|min:6',
            'ppl_name'=>'required|min:5',
            'jenis_kelamin'=>'required',
            'allocation_place'=>'required',
            'email'=>'required|unique:users,email',
            'avatar'=>'mimes:jpg,png,jpeg'
        ]);

        //insert to users_table
        $user = new user;
        $user->role = 'ppl';
        $user->name = $request->ppl_name;
        $user->email = $request->email;
        $user->password = bcrypt('rahasia');
        $user->save();  

        //insert to ppl_table    
        $request->request->add(['users_id'=> $user->id]);
        $ppl = ppl::create($request->all());

        if($request->hasfile('avatar')){
            $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName());
            $ppl->avatar=$request->file('avatar')->getClientOriginalName();
            $ppl->save();
        }

        return redirect('/PPL')->with('sukses','Data Berhasil diinput');
    }
  

    
    public function store(Request $request)
    {
        //
    }

   
    public function show($id)
    {
        //
    }

  
    public function edit($id)
    {
        $ppl = ppl::find($id);
        return view('DinasPertanian.PPL.edit',['ppl' => $ppl]);  
    }

    
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'ppl_nip'=>'required|min:6',
            'ppl_name'=>'required|min:5',
            'jenis_kelamin'=>'required',
            'allocation_place'=>'required',
            'avatar'=>'mimes:jpg,png,jpeg'
        ]);

        $ppl = ppl::find($id);
        $ppl->update($request->all());

        if($request->hasfile('avatar')){
            $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName());
            $ppl->avatar=$request->file('avatar')->getClientOriginalName();
            $ppl->save();
        }

        return redirect('/PPL')->with('sukses','Data Berhasil Diperbaharui');
    }

    function delete($id)
    {
        $ppl = ppl::find($id);
        $ppl->delete($ppl);
        return redirect('/PPL')->with('sukses','PPL Berhasil Di non aktifkan (Silahkan Cek Pada Trash PPL)');
    }
    public function profile($id){
        $ppl = ppl::find($id);
        return view('DinasPertanian.PPL.profile',['ppl' => $ppl]);
    }

    public function tampil_hapus(Request $request){
        $data_ppl = ppl::onlyTrashed()->paginate(10);
        return view('DinasPertanian.PPL.nonaktif',['data_ppl'=>$data_ppl]);
    }
    public function restore($id){
        $ppl = ppl::withTrashed()->where('id', $id)->first();
        $ppl->restore();
        return redirect()->back()->with('sukses','PPL Aktif Kembali(Silahkan Cek Pada List PPL)');
    }
    public function kill($id){
        $ppl = ppl::withTrashed()->where('id', $id)->first();
        $ppl->forceDelete();

        return redirect()->back()->with('sukses','PPL Berhasil Dihapus');
    }
}
