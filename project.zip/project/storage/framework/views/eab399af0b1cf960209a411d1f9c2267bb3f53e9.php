

<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                <br>
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">UBAH DATA PPL</p></b></h1>
                        </div>
                        <div class="panel-body">
                            <?php if(Session::has('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(Session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                            <form action = "/PPL/<?php echo e($ppl->id); ?>/update" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group <?php echo e($errors->has('ppl_nip') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">NIP </label>
                                    <input type="text" class="form-control" name="ppl_nip"  placeholder="Masukkan NIP PPL" value="<?php echo e($ppl->ppl_nip); ?>">
                                <?php if($errors->has('ppl_nip')): ?>
                                    <span class="help-block"><?php echo e($errors->first('ppl_nip')); ?></span>
                                <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('ppl_name') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">NAMA PPL</label>
                                    <input type="text" class="form-control" name="ppl_name"  placeholder="Masukkan Nama PPL" value="<?php echo e($ppl->ppl_name); ?>">
                                <?php if($errors->has('ppl_name')): ?>
                                    <span class="help-block"><?php echo e($errors->first('ppl_name')); ?></span>
                                <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('jenis_kelamin') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">PILIH JENIS KELAMIN</label>
                                    <select name="jenis_kelamin" class="form-control" id="exampleformControlSelect1">
                                        <option>select...</option>
                                        <option value="L">Laki-Laki</option>
                                        <option value="P">Perempuan</option>
                                    </select>
                                <?php if($errors->has('jenis_kelamin')): ?>
                                    <span class="help-block"><?php echo e($errors->first('jenis_kelamin')); ?></span>
                                <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('allocation_place') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">LOKASI KERJA</label>
                                    <input type="text" class="form-control" name="allocation_place"  placeholder="Masukkan Lokasi Kerja (Kecamatan)" value="<?php echo e($ppl->allocation_place); ?>">
                                <?php if($errors->has('allocation_place')): ?>
                                    <span class="help-block"><?php echo e($errors->first('allocation_place')); ?></span>
                                <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('avatar') ? 'has-error' : ''); ?> ">
                                    <label for="exampleInputEmail1">Avatar</label>
                                    <input type="file" name="avatar" class="form-control"  value="<?php echo e($ppl->avatar); ?>">
                                <?php if($errors->has('avatar')): ?>
                                    <span class="help-block"><?php echo e($errors->first('avatar')); ?></span>
                                <?php endif; ?>
                                </div>
                                <button type="submit" class="btn btn-warning btn-sm">Update</button>
                            </form>
                        </div>
                    </div>
                </div>			       
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/PPL/edit.blade.php ENDPATH**/ ?>