<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li><a href="/dashboard" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
						<?php if(auth()->user()->role == 'disper'): ?>
						<li>
							<a href="#Pengajuan" data-toggle="collapse" class="collapsed"><i class="lnr lnr-user"></i> <span>Pengajuan Rdkk</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="Pengajuan" class="collapse ">
								<ul class="nav">
									<li><a href="<?php echo e(route('Pengajuan-rdkk.index')); ?>" class="active"><i class="lnr lnr-list"></i><span>List Pengajuan</span></a></li>
									<li><a href="/List/Pengajuan-diterima" class="active"><i class="lnr lnr-list"></i><span>Diterima</span></a></li>
									<li><a href="/List/Pengajuan-ditolak" class="active"><i class="lnr lnr-list"></i><span>Ditolak</span></a></li>
								</ul>
							</div>
						</li>
						<li>
							<a href="#KelompokTani" data-toggle="collapse" class="collapsed"><i class="lnr lnr-users"></i> <span>Kelompok Tani</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="KelompokTani" class="collapse ">
								<ul class="nav">
									<li><a href="/KelompokTani" class="active"><i class="lnr lnr-list"></i><span>List KelompokTani</span></a></li>
									<li><a href="/KelompokTani/nonaktif" class="active"><i class="lnr lnr-trash"></i><span>Trash KelompokTani</span></a></li>
								</ul>
							</div>
						</li>
						<li>
							<a href="#PPL" data-toggle="collapse" class="collapsed"><i class="lnr lnr-user"></i> <span>PPL</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="PPL" class="collapse ">
								<ul class="nav">
									<li><a href="/PPL" class="active"><i class="lnr lnr-list"></i><span>List PPL</span></a></li>
									<li><a href="/PPL/nonaktif" class="active"><i class="lnr lnr-trash"></i><span>Trash PPL</span></a></li>
								</ul>
							</div>
						</li>
						<li>
							<a href="#Pengecer" data-toggle="collapse" class="collapsed"><i class="lnr lnr-user"></i> <span>Pengecer</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="Pengecer" class="collapse ">
								<ul class="nav">
									<li><a href="/Pengecer" class="active"><i class="lnr lnr-list"></i><span>List Pengecer</span></a></li>
									<li><a href="/Pengecer/nonaktif" class="active"><i class="lnr lnr-trash"></i><span>Trash Pengecer</span></a></li>
								</ul>
							</div>
						</li>
						<li>
							<a href="#Pupuk" data-toggle="collapse" class="collapsed"><i class="lnr lnr-leaf"></i> <span>Pupuk</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="Pupuk" class="collapse ">
								<ul class="nav">
									<li><a href="/Pupuk" class="active"><i class="lnr lnr-list"></i><span>Daftar Pupuk</span></a></li>
								</ul>
							</div>
						</li>
						<li><a href="/Pengecer/Laporan" class="active"><i class="lnr lnr-chart-bars"></i><span>Laporan</span></a></li>
						<?php endif; ?>
						<?php if(auth()->user()->role=='kelompok'): ?>
						<li>
							<a href="#Pupuk" data-toggle="collapse" class="collapsed"><i class="lnr lnr-enter"></i> <span>Pengajuan</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="Pupuk" class="collapse ">
								<ul class="nav">
									<li><a href="<?php echo e(route('Pengajuan-rdkk.index')); ?>" class="active"><i class="lnr lnr-list"></i><span>Daftar Pengajuan</span></a></li>
									<li><a href="/List/Pengajuan-diterima" class="active"><i class="lnr lnr-list"></i><span>Diterima</span></a></li>
									<li><a href="/List/Pengajuan-ditolak" class="active"><i class="lnr lnr-list"></i><span>Ditolak</span></a></li>
								</ul>
							</div>
						</li>
						<?php endif; ?>
						<?php if(auth()->user()->role=='ppl'): ?>
						<li>
							<a href="#Pupuk" data-toggle="collapse" class="collapsed"><i class="lnr lnr-enter"></i> <span>Pengajuan</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="Pupuk" class="collapse ">
								<ul class="nav">
									<li><a href="<?php echo e(route('Pengajuan-rdkk.index')); ?>" class="active"><i class="lnr lnr-list"></i><span>Daftar Pengajuan</span></a></li>
								</ul>
								<ul class="nav">
									<li><a href="/List/Approve-ppl" class="active"><i class="lnr lnr-list"></i><span>Daftar Approve</span></a></li>
							</ul>
							<ul class="nav">
									<li><a href="/List/Rejected-ppl" class="active"><i class="lnr lnr-list"></i><span>Daftar Rejected</span></a></li>
							</ul>
							</div>
							
						</li>
						<?php endif; ?>
						<?php if(auth()->user()->role=='pengecer'): ?>
						<li>
							<a href="#Pupuk" data-toggle="collapse" class="collapsed"><i class="lnr lnr-enter"></i> <span>Pengajuan</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="Pupuk" class="collapse ">
								<ul class="nav">
									<li><a href="<?php echo e(route('Pengajuan-rdkk.index')); ?>" class="active"><i class="lnr lnr-list"></i><span>Daftar Pengajuan</span></a></li>
									<li><a href="/List/Pengajuan-diterima" class="active"><i class="lnr lnr-list"></i><span>Diterima</span></a></li>
								</ul>
							</div>
							<li><a href="/Pengecer/Laporan" class="active"><i class="lnr lnr-chart-bars"></i><span>Laporan</span></a></li>
							<li><a href="/Transaksi" class="active"><i class="lnr lnr-file-add"></i><span>Data Transaksi</span></a></li>
						</li>
						<?php endif; ?>
					</ul>
				

				</nav>
			</div>
		</div><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/Layouts/Include/sidebar.blade.php ENDPATH**/ ?>