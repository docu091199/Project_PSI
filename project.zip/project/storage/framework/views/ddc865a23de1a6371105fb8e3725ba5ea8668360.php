

<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                <br>
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">UBAH DATA PPL</p></b></h1>
                        </div>
                        <div class="panel-body">
                            <?php if(Session::has('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(Session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                            <form action = "/Pengecer/<?php echo e($pengecer->id); ?>/update" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group <?php echo e($errors->has('pengecer_id') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">ID Pengecer</label>
                                    <input type="text" class="form-control" name="pengecer_id"  placeholder="Masukkan ID" value="<?php echo e($pengecer->pengecer_id); ?>">
                                    <?php if($errors->has('pengecer_id')): ?>
                                    <span class="help-block"><?php echo e($errors->first('pengecer_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">Nama Pengecer</label>
                                    <input type="text" class="form-control" name="name" placeholder="Masukkan Nama Pengecer (Toko Resmi)" value="<?php echo e($pengecer->name); ?>">
                                    <?php if($errors->has('name')): ?>
                                    <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('region') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">Region</label>
                                    <input type="text" class="form-control" name="region"  placeholder="Masukkan Region" value="<?php echo e($pengecer->region); ?>">
                                    <?php if($errors->has('region')): ?>
                                    <span class="help-block"><?php echo e($errors->first('region')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputTextarea1">Alamat</label>
                                    <textarea type="text" class="form-control" name="address"  placeholder="Masukkan Alamat" ><?php echo e($pengecer->address); ?></textarea>
                                    <?php if($errors->has('address')): ?>
                                    <span class="help-block"><?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Avatar</label>
                                    <input type="file" name="avatar" class="form-control"  value="<?php echo e($pengecer->avatar); ?>">
                                </div>
                                <div class="form-group form-check <?php echo e($errors->has('avatar') ? 'has-error' : ''); ?>">
                                    <?php if($errors->has('avatar')): ?>
                                    <span class="help-block"><?php echo e($errors->first('avatar')); ?></span>
                                    <?php endif; ?>
                                </div>
                        <button type="submit" class="btn btn-warning btn-sm">Update</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/Pengecer/edit.blade.php ENDPATH**/ ?>