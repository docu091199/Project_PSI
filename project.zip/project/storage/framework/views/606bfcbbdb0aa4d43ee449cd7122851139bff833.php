

<?php $__env->startSection('content'); ?>

<div class="main">
    <div class="main-container">
        <div class="container-fluid">
            <div class="center">
            <div class="col-md-3">
                    </div>

                <div class="col-md-6">
                <br>
                    <div class="panel">
                        <div class="panel-heading">
                            <h2 class="panel-title"><b>
                                    <p class="text-center">Detail Pengajuan RDKK</p>
                                </b></h2>
                            <div class="right">
                                <?php if(auth()->user()->role=='pengecer'): ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="panel-body">
                            <?php if(Session::has('sukses')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(Session('sukses')); ?>

                            </div>
                            <?php endif; ?>
                           
                            <div class="card" style="width: 40rem;">
                                <div class="card-body">

                                    <table  class="table table-borderless">
                                        <thead>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th scope="row">Nama Kelompok</th>
                                                <td><?php echo e($rdkk->nama_kelompok); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Alamat</th>
                                                <td><?php echo e($rdkk->alamat); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Nama Pengecer</th>
                                                <td><?php echo e($rdkk->nama_pengecer); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Luas Tanah</th>
                                                <td><?php echo e($rdkk->luas_tanah); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Nama Pupuk</th>
                                                <td><?php echo e($rdkk->nama_pupuk); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Jumlah Pupuk</th>
                                                <td><?php echo e($rdkk->jumlah_pupuk); ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Waktu Penggunaan</th>
                                                <td><?php echo e($rdkk->waktu_penggunaan); ?></td>
                                            </tr>
											<tr>
                                                <th scope="row">Status</th>
                                                <td><?php echo e($rdkk->status_dinper); ?></td>
                                            </tr>
										

                                        </tbody>
                                    </table>
                                </div>
                            </div>
    <!-- Kelompok -->
    <?php if(auth()->user()->role=='kelompok'): ?>
    <?php if($rdkk->status_ppl=='Menunggu' || $rdkk->status_ppl=='Approve'): ?>
		
	<?php endif; ?>

	<?php if($rdkk->status_ppl=='rejected'): ?>
	<a href="<?php echo e(route('Pengajuan-rdkk.index')); ?>" class="card-link">Kembali</a>
	<?php endif; ?>
    <?php endif; ?>

    <!--PPL-->
    <?php if(auth()->user()->role=='ppl'): ?>
        <?php if($rdkk->status_ppl=='Menunggu'): ?>
        <div class="footer"> 
        <div class="col-md-3">
            <form action="/Pengajuan-rdkk/<?php echo e($rdkk->id); ?>/approve-ppl" method="post" class="d-inline">
            <?php echo method_field('patch'); ?>
             <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-sm btn-primary">Approve</button>
            </form>
        </div>
        <div class="col-md-2">
            <form action="/pengajuan-rdkk/<?php echo e($rdkk->id); ?>/rejected-ppl" method="post" class="d-inline">
            <?php echo method_field('patch'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-sm btn-danger">Rejected</button>
            </form>
        </div>
           
        </div>
        <?php elseif($rdkk->status_ppl=='Approve'): ?>
        <button type="submit" class="btn btn-primary" disabled> Sudah Di Approve</button>
            <a href="<?php echo e(route('Pengajuan-rdkk.index')); ?>" class="card-link">Kembali</a>

        <?php else: ?>
        <button type="submit" class="btn btn-danger" disabled> Rejected </button>
            <a href="<?php echo e(route('Pengajuan-rdkk.index')); ?>" class="card-link">Kembali</a>
        <?php endif; ?>
    <?php endif; ?>


    <!-- Pengecer -->
    <?php if(auth()->user()->role=='pengecer'): ?>
    <?php if($rdkk->status_pengecer=='Menunggu'): ?>
    <div class="footer">
    <div class="col-md-3">
    <form action="/Pengajuan-rdkk/<?php echo e($rdkk->id); ?>/konfirmasi-pengecer" method="post" class="d-inline">
     <?php echo method_field('patch'); ?>
        <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-primary">Konfirmasi</button>
    </form>
    </div>
    <?php elseif($rdkk->status_pengecer='Konfirmasi'): ?>

    <button type="submit" class="btn btn-primary" disabled> Sudah Di Konfirmasi</button>
    <a href="<?php echo e(route('Pengajuan-rdkk.index')); ?>" class="card-link">Kembali</a>
    </div>
    <?php endif; ?>
    <?php endif; ?>


    <!-- Dinas -->
    <?php if(auth()->user()->role=='disper'): ?>
    <?php if($rdkk->status_dinper=='Menunggu'): ?>
    <form action="/Pengajuan-rdkk/<?php echo e($rdkk->id); ?>/dinas-setuju" method="post" class="d-inline">

    <?php echo method_field('patch'); ?>
    <?php echo csrf_field(); ?>
    <div class="footer">
        <div class ="col-md-3">
        <button type="submit" class="btn btn-primary">Setuju</button>
        </form>
        </div>
        <div class="col-md-6">
        <form action="/Pengajuan-rdkk/<?php echo e($rdkk->id); ?>/dinas-tolak" method="post" class="d-inline">
        <button type="submit" class="btn btn-danger">Tolak</button>
        </div>
        <?php echo method_field('patch'); ?>
        <?php echo csrf_field(); ?>
    </div>
    </form>
  

    <?php elseif($rdkk->status_dinper=='Setuju'): ?>
    <button type="submit" class="btn btn-primary" disabled> Telah Disetujui</button>
    <a href="<?php echo e(route('Pengajuan-rdkk.index')); ?>" class="card-link d-inline">Kembali</a>
    <?php else: ?>
    <button type="submit" class="btn btn-danger" disabled> Telah Ditolak</button>
    <a href="<?php echo e(route('Pengajuan-rdkk.index')); ?>" class="card-link d-inline">Kembali</a>
    <?php endif; ?>
    <?php endif; ?>


    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/Rdkk_Ketua/show.blade.php ENDPATH**/ ?>