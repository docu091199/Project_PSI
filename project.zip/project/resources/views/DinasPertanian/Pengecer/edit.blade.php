@extends('Layouts.master')

@section('content')
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                <br>
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">UBAH DATA PPL</p></b></h1>
                        </div>
                        <div class="panel-body">
                            @if(Session::has('sukses'))
                                <div class="alert alert-success" role="alert">
                                {{Session('sukses') }}
                                </div>
                            @endif
                            <form action = "/Pengecer/{{$pengecer->id}}/update" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="form-group {{$errors->has('pengecer_id') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">ID Pengecer</label>
                                    <input type="text" class="form-control" name="pengecer_id"  placeholder="Masukkan ID" value="{{$pengecer->pengecer_id}}">
                                    @if($errors->has('pengecer_id'))
                                    <span class="help-block">{{$errors->first('pengecer_id')}}</span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('name') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">Nama Pengecer</label>
                                    <input type="text" class="form-control" name="name" placeholder="Masukkan Nama Pengecer (Toko Resmi)" value="{{$pengecer->name}}">
                                    @if($errors->has('name'))
                                    <span class="help-block">{{$errors->first('name')}}</span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('region') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">Region</label>
                                    <input type="text" class="form-control" name="region"  placeholder="Masukkan Region" value="{{$pengecer->region}}">
                                    @if($errors->has('region'))
                                    <span class="help-block">{{$errors->first('region')}}</span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('address') ? 'has-error' : ''}}">
                                    <label for="exampleInputTextarea1">Alamat</label>
                                    <textarea type="text" class="form-control" name="address"  placeholder="Masukkan Alamat" >{{$pengecer->address}}</textarea>
                                    @if($errors->has('address'))
                                    <span class="help-block">{{$errors->first('address')}}</span>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Avatar</label>
                                    <input type="file" name="avatar" class="form-control"  value="{{$pengecer->avatar}}">
                                </div>
                                <div class="form-group form-check {{$errors->has('avatar') ? 'has-error' : ''}}">
                                    @if($errors->has('avatar'))
                                    <span class="help-block">{{$errors->first('avatar')}}</span>
                                    @endif
                                </div>
                        <button type="submit" class="btn btn-warning btn-sm">Update</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection