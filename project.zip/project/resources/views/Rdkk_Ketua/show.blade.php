@extends('Layouts.master')

@section('content')

<div class="main">
    <div class="main-container">
        <div class="container-fluid">
            <div class="center">
            <div class="col-md-3">
                    </div>

                <div class="col-md-6">
                <br>
                    <div class="panel">
                        <div class="panel-heading">
                            <h2 class="panel-title"><b>
                                    <p class="text-center">Detail Pengajuan RDKK</p>
                                </b></h2>
                            <div class="right">
                                @if(auth()->user()->role=='pengecer')
                                @endif
                            </div>
                        </div>
                        <div class="panel-body">
                            @if(Session::has('sukses'))
                            <div class="alert alert-success" role="alert">
                                {{Session('sukses') }}
                            </div>
                            @endif
                           
                            <div class="card" style="width: 40rem;">
                                <div class="card-body">

                                    <table  class="table table-borderless">
                                        <thead>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th scope="row">Nama Kelompok</th>
                                                <td>{{$rdkk->nama_kelompok}}</td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Alamat</th>
                                                <td>{{$rdkk->alamat}}</td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Nama Pengecer</th>
                                                <td>{{$rdkk->nama_pengecer}}</td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Luas Tanah</th>
                                                <td>{{$rdkk->luas_tanah}}</td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Nama Pupuk</th>
                                                <td>{{$rdkk->nama_pupuk}}</td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Jumlah Pupuk</th>
                                                <td>{{$rdkk->jumlah_pupuk}}</td>
                                            </tr>
                                            <tr>
                                                <th scope="row">Waktu Penggunaan</th>
                                                <td>{{$rdkk->waktu_penggunaan}}</td>
                                            </tr>
											<tr>
                                                <th scope="row">Status</th>
                                                <td>{{$rdkk->status_dinper}}</td>
                                            </tr>
										

                                        </tbody>
                                    </table>
                                </div>
                            </div>
    <!-- Kelompok -->
    @if(auth()->user()->role=='kelompok')
    @if($rdkk->status_ppl=='Menunggu' || $rdkk->status_ppl=='Approve')
		
	@endif

	@if($rdkk->status_ppl=='rejected')
	<a href="{{route('Pengajuan-rdkk.index')}}" class="card-link">Kembali</a>
	@endif
    @endif

    <!--PPL-->
    @if(auth()->user()->role=='ppl')
        @if($rdkk->status_ppl=='Menunggu')
        <div class="footer"> 
        <div class="col-md-3">
            <form action="/Pengajuan-rdkk/{{$rdkk->id}}/approve-ppl" method="post" class="d-inline">
            @method('patch')
             @csrf
            <button type="submit" class="btn btn-sm btn-primary">Approve</button>
            </form>
        </div>
        <div class="col-md-2">
            <form action="/pengajuan-rdkk/{{$rdkk->id}}/rejected-ppl" method="post" class="d-inline">
            @method('patch')
            @csrf
            <button type="submit" class="btn btn-sm btn-danger">Rejected</button>
            </form>
        </div>
           
        </div>
        @elseif($rdkk->status_ppl=='Approve')
        <button type="submit" class="btn btn-primary" disabled> Sudah Di Approve</button>
            <a href="{{route('Pengajuan-rdkk.index')}}" class="card-link">Kembali</a>

        @else
        <button type="submit" class="btn btn-danger" disabled> Rejected </button>
            <a href="{{route('Pengajuan-rdkk.index')}}" class="card-link">Kembali</a>
        @endif
    @endif


    <!-- Pengecer -->
    @if(auth()->user()->role=='pengecer')
    @if($rdkk->status_pengecer=='Menunggu')
    <div class="footer">
    <div class="col-md-3">
    <form action="/Pengajuan-rdkk/{{$rdkk->id}}/konfirmasi-pengecer" method="post" class="d-inline">
     @method('patch')
        @csrf
    <button type="submit" class="btn btn-primary">Konfirmasi</button>
    </form>
    </div>
    @elseif($rdkk->status_pengecer='Konfirmasi')

    <button type="submit" class="btn btn-primary" disabled> Sudah Di Konfirmasi</button>
    <a href="{{route('Pengajuan-rdkk.index')}}" class="card-link">Kembali</a>
    </div>
    @endif
    @endif


    <!-- Dinas -->
    @if(auth()->user()->role=='disper')
    @if($rdkk->status_dinper=='Menunggu')
    <form action="/Pengajuan-rdkk/{{$rdkk->id}}/dinas-setuju" method="post" class="d-inline">

    @method('patch')
    @csrf
    <div class="footer">
        <div class ="col-md-3">
        <button type="submit" class="btn btn-primary">Setuju</button>
        </form>
        </div>
        <div class="col-md-6">
        <form action="/Pengajuan-rdkk/{{$rdkk->id}}/dinas-tolak" method="post" class="d-inline">
        <button type="submit" class="btn btn-danger">Tolak</button>
        </div>
        @method('patch')
        @csrf
    </div>
    </form>
  

    @elseif($rdkk->status_dinper=='Setuju')
    <button type="submit" class="btn btn-primary" disabled> Telah Disetujui</button>
    <a href="{{route('Pengajuan-rdkk.index')}}" class="card-link d-inline">Kembali</a>
    @else
    <button type="submit" class="btn btn-danger" disabled> Telah Ditolak</button>
    <a href="{{route('Pengajuan-rdkk.index')}}" class="card-link d-inline">Kembali</a>
    @endif
    @endif


    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection()
