

<?php $__env->startSection('content'); ?>

<div class="main">	
			<div class="main-content">
				<div class="container-fluid">
					<div class="panel panel-profile">
						<div class="clearfix">
						
							<div class="profile-left">
								
								<div class="profile-header">
									<div class="overlay"></div>
									<div class="profile-main">
										<img src="<?php echo e($ppl->getAvatar()); ?>" width="140" height="140"  class="img-circle" alt="Avatar">
										<h3 class="name"><?php echo e($ppl->ppl_name); ?></h3>
										<span class="online-status status-available">Available</span>
									</div>
									<div class="profile-stat">
										<div class="row">	
										</div>
									</div>
								</div>
								
								<div class="profile-detail">
									<div class="profile-info">
										<h4 class="heading">Data PPL</h4>
										<ul class="list-unstyled list-justify">
											<li>Nama PPL<span><?php echo e($ppl->ppl_name); ?></span></li>
											<li>Lokasi Kerja<span><?php echo e($ppl->allocation_place); ?></span></li>
											<li> <span></span></li>
											<li> <span></span></li>
										</ul>
										<div class="text-center"><a href="/PPL/<?php echo e($ppl->id); ?>/edit" class="btn btn-warning">Edit Profile</a></div>
									</div>									
								</div>
							
							</div>
							
							<div class="profile-right">
								
								
								<div class="custom-tabs-line tabs-line-bottom left-aligned">
									<ul class="nav" role="tablist">
										<li class="active"><a href="#tab-bottom-left1" role="tab" data-toggle="tab">Aktivitas Terakhir</a></li>
									</ul>
								</div>
								<div class="tab-content">
									<div class="tab-pane fade in active" id="tab-bottom-left1">
										<ul class="list-unstyled activity-timeline">
											<li>
												<i class="fa fa-comment activity-icon"></i>
												<p>Commented on post <a href="#">Prototyping</a> <span class="timestamp">2 minutes ago</span></p>
											</li>
											<li>
												<i class="fa fa-cloud-upload activity-icon"></i>
												<p>Uploaded new file <a href="#">Proposal.docx</a> to project <a href="#">New Year Campaign</a> <span class="timestamp">7 hours ago</span></p>
											</li>
											<li>
												<i class="fa fa-plus activity-icon"></i>
												<p>Added <a href="#">Martin</a> and <a href="#">3 others colleagues</a> to project repository <span class="timestamp">Yesterday</span></p>
											</li>
											<li>
												<i class="fa fa-check activity-icon"></i>
												<p>Finished 80% of all <a href="#">assigned tasks</a> <span class="timestamp">1 day ago</span></p>
											</li>
										</ul>
										<div class="margin-top-30 text-center"><a href="#" class="btn btn-default">See all activity</a></div>
									</div>
									
								
							</div>
							
						</div>
					</div>
				</div>
			</div>
			
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/PPL/profile.blade.php ENDPATH**/ ?>