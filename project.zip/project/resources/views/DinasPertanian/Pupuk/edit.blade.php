@extends('Layouts.master')

@section('content')
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">UBAH DATA PUPUK BERSUBSIDI</p></b></h1>
                        </div>
                        <div class="panel-body">
                            @if(Session::has('sukses'))
                                <div class="alert alert-success" role="alert">
                                {{Session('sukses') }}
                                </div>
                            @endif
                            <form action = "/Pupuk/{{$pupuk->id}}/update" method="POST">
                                @csrf
                                <div class="form-group {{$errors->has('pupuk_id') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">KODE</label>
                                    <input type="text" class="form-control" name="pupuk_id"  placeholder="Masukkan KODE PUPUK" value="{{$pupuk->pupuk_id}}">
                                    @if($errors->has('pupuk_id'))
                                    <span class="help-block">{{$errors->first('pupuk_id')}}</span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('name') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">NAMA Pupuk</label>
                                    <input type="text" class="form-control" name="name"  placeholder="Masukkan Nama Pupuk" value="{{$pupuk->name}}">
                                    @if($errors->has('name'))
                                    <span class="help-block">{{$errors->first('name')}}</span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('jenis') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">PILIH JENIS PUPUK</label>
                                    <select name="jenis" class="form-control" id="exampleformControlSelect1">
                                        <option placeholder>select...</option>
                                        <option value="Kimia">Kimia</option>
                                        <option value="Organik">Organik</option>
                                    </select>
                                    @if($errors->has('jenis'))
                                    <span class="help-block">{{$errors->first('jenis')}}</span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('harga') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">HARGA PUPUK</label>
                                    <input type="text" class="form-control" name="harga"  placeholder="Masukkan Harga Pupuk(Rp)" value="{{$pupuk->harga}}">
                                    @if($errors->has('harga'))
                                    <span class="help-block">{{$errors->first('harga')}}</span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('jumlah_pupuk') ? 'has-error' : ''}}">
                                    <label for="exampleInputEmail1">JUMLAH PEMESANAN PUPUK</label>
                                    <input type="text" class="form-control" name="jumlah_pupuk"  placeholder="Masukkan Harga Pupuk(Rp)" value="{{$pupuk->jumlah_pupuk}}">
                                    @if($errors->has('jumlah_pupuk'))
                                    <span class="help-block">{{$errors->first('jumlah_pupuk')}}</span>
                                    @endif
                                </div>
                            <button type="submit" class="btn btn-warning">Update</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection