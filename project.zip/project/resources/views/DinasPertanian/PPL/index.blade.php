@extends('Layouts.master')

@section('content')
<div class="main">
  <div class="main-container">
    <div class = "container-fluid">
      <div class = "row">
        <div class = "col-md-12">
        <br>
          <div class="panel">
				    <div class="panel-heading">
              <h2 class="panel-title"><b><p class="text-center">DATA PPL</p></b></h2>
                <div class="right">
                  <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>  
                </div>
						</div>
						<div class="panel-body">
            @if(Session::has('sukses'))
              <div class="alert alert-success" role="alert">
                {{Session('sukses') }}
              </div>
            @endif             
						<table class="table table-hover">
							<thead>
								<tr>
                  <td>No</td>
                  <td>NIP</td>
                  <td>NAMA PPL</td>
                  <td>JENIS KELAMIN</td>
                  <td>LOKASI KERJA</td>
                  <td>AKSI</td>
								</tr>
						  </thead>
              <tbody>
                @foreach($data_ppl as $result => $hasil)
                <tr>
                  <td>{{$result + $data_ppl->firstitem()}}</td>
                  <td><a href="/PPL/{{$hasil->id}}/profile">{{$hasil->ppl_nip}}</a></td>
                  <td><a href="/PPL/{{$hasil->id}}/profile">{{$hasil->ppl_name}}</a></td>
                  <td>{{$hasil->jenis_kelamin}}</td>
                  <td>{{$hasil->allocation_place}}</td>
                  <td><a href="/PPL/{{$hasil->id}}/edit" class="btn btn-warning btn-sm"> Edit</a>
                      <a href="/PPL/{{$hasil->id}}/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin mengganti status??')">Non Aktif</a>
                  </td>
                </tr>
                  @endforeach     
						  </tbody>
						</table>
          {{$data_ppl->links()}} 
					</div>
				</div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Masukkan Data PPL</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "/PPL/create" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group {{$errors->has('ppl_nip') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">NIP </label>
                <input type="text" class="form-control" name="ppl_nip"  placeholder="Masukkan NIP PPL" value="{{old('ppl_nip')}}">
                @if($errors->has('ppl_nip'))
                  <span class="help-block">{{$errors->first('ppl_nip')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('ppl_name') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">NAMA PPL</label>
                <input type="text" class="form-control" name="ppl_name"  placeholder="Masukkan Nama PPL" value="{{old('ppl_name')}}">
                @if($errors->has('ppl_name'))
                  <span class="help-block">{{$errors->first('ppl_name')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('jenis_kelamin') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">PILIH JENIS KELAMIN</label>
                <select name="jenis_kelamin" class="form-control" id="exampleformControlSelect1">
                    <option placeholder>select...</option>
                    <option value="L">Laki-Laki</option>
                    <option value="P">Perempuan</option>
                </select>
                @if($errors->has('jenis_kelamin'))
                  <span class="help-block">{{$errors->first('jenis_kelamin')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('allocation_place') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">LOKASI KERJA</label>
                <input type="text" class="form-control" name="allocation_place"  placeholder="Masukkan Lokasi Kerja (Kecamatan)" value="{{old('allocation_place')}}">
                @if($errors->has('allocation_place'))
                  <span class="help-block">{{$errors->first('allocation_place')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('email') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">email</label>
                <input type="email" class="form-control" name="email"  placeholder="Masukkan Email" value="{{old('email')}}">
                @if($errors->has('email'))
                  <span class="help-block">{{$errors->first('email')}}</span>
                @endif
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Avatar</label>
                  <input type="file" name="avatar" class="form-control"  value="{{old('avatar')}}">
            </div>
            <div class="form-group form-check {{$errors->has('avatar') ? 'has-error' : ''}}">
                @if($errors->has('avatar'))
                  <span class="help-block">{{$errors->first('avatar')}}</span>
                @endif
            </div>
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>

@endsection

 

