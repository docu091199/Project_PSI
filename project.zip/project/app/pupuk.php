<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pupuk extends Model
{
    protected $table='pupuk';
    protected $fillable=['pupuk_id','name','jenis','harga','jumlah_pupuk'];

    public function rdkk(){
        return $this->hasMany(Rdkk::class);
    }
}
