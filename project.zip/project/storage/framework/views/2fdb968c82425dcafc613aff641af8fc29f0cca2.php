

<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                <br>
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">RENCANA DEFINIT KEBUTUHAN KELOMPOK</p></b></h1>
                        </div>
                        <div class="panel-body">
                            <?php if(Session::has('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(Session('sukses')); ?>

                        </div>
                            <?php endif; ?>
                        <form action = "" method="POST">
                            <?php echo csrf_field(); ?>
                            <table class="table table-hover">
				<thead>
				<tr>
                  <td>No</td>
                  <td>Nama KELOMPOK</td>
                  <td>NAMA PENGECER</td>
                  <td>JUMLAH PUPUK</td>
                  <td>ALAMAT</td>
                  <td>WAKTU PEMAKAIAN</td>
                  <td>AKSI</td>
				</tr>
				</thead>
                <tbody>
                <?php $__currentLoopData = $data_rdkk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($result + $data_rdkk->firstitem()); ?></td>
                  <td><?php echo e($hasil->nama_kelompok); ?></a></td>
                  <td><?php echo e($hasil->pengecer_id); ?></a></td>
                  <td><?php echo e($hasil->jumlah_pupuk); ?> kg</td>
                  <td><?php echo e($hasil->alamat); ?></td>
                  <td><?php echo e($hasil->waktu_penggunaan); ?></td>
                  <td><a href="" class="btn btn-warning btn-sm"> Edit</a>
                      <a href="" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin mengganti status??')">Delete</a>
                  </td>
                </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
				</tbody>
			</table>
          <?php echo e($data_rdkk->links()); ?> 
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/RDKK/index.blade.php ENDPATH**/ ?>