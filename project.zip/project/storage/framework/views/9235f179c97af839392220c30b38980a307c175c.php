


<?php $__env->startSection('content'); ?>
<div class="main">
      <div class="main-container">
          <div class = "container-fluid">
            <div class = "row">
              <div class = "col-md-12">
              <br>
              <div class="panel">
				<div class="panel-heading">
					<h1 class="panel-title"><b><p class="text-center">UBAH DATA KELOMPOK TANI</p></b></h1>
				</div>
					<div class="panel-body">
                    <?php if(Session::has('sukses')): ?>
                        <div class="alert alert-success" role="alert">
                         <?php echo e(Session('sukses')); ?>

                        </div>
                    <?php endif; ?>
                    <form action = "/KelompokTani/<?php echo e($keltan->id); ?>/update" method="POST" enctype="multipart/form-data">
                       <?php echo csrf_field(); ?>
                        <div class="form-group <?php echo e($errors->has('keltan_id') ? 'has-error' : ''); ?>">
                            <label for="exampleInputEmail1">ID Kelompok Tani</label>
                            <input type="text" class="form-control" name="keltan_id"  placeholder="Masukkan ID" value="<?php echo e($keltan->keltan_id); ?>">
                                <?php if($errors->has('keltan_id')): ?>
                                <span class="help-block"><?php echo e($errors->first('keltan_id')); ?></span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                            <label for="exampleInputEmail1">Nama Kelompok</label>
                            <input type="text" class="form-control" name="name" placeholder="Masukkan Nama Kelompok" value="<?php echo e($keltan->name); ?>">
                                <?php if($errors->has('name')): ?>
                                <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('leader') ? 'has-error' : ''); ?>">
                            <label for="exampleInputEmail1">Nama Ketua</label>
                            <input type="text" class="form-control" name="leader"  placeholder="Masukkan Nama Ketua" value="<?php echo e($keltan->leader); ?>">
                                <?php if($errors->has('leader')): ?>
                                <span class="help-block"><?php echo e($errors->first('leader')); ?></span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('birth') ? 'has-error' : ''); ?>">
                            <label for="exampleInputEmail1">Tanggal dibentuk</label>
                            <input type="date" class="form-control" name="birth"  value="<?php echo e($keltan->birth); ?>">
                                <?php if($errors->has('birth')): ?>
                                <span class="help-block"><?php echo e($errors->first('birth')); ?></span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('wilayah') ? 'has-error' : ''); ?>">
                            <label for="exampleInputEmail1">Luas Wilayah</label>
                            <input type="text" class="form-control" name="wilayah"  placeholder="Masukkan Jumlah Luas Wilayah (dalam satuan Hh)" value="<?php echo e($keltan->wilayah); ?>">
                                <?php if($errors->has('wilayah')): ?>
                                <span class="help-block"><?php echo e($errors->first('wilayah')); ?></span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('member') ? 'has-error' : ''); ?>">
                            <label for="exampleInputEmail1">Jumlah Anggota</label>
                            <input type="text" class="form-control" name="member"  placeholder="Masukkan Jumlah Anggota" value="<?php echo e($keltan->member); ?>">
                            <?php if($errors->has('member')): ?>
                            <span class="help-block"><?php echo e($errors->first('member')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('avatar') ? 'has-error' : ''); ?>">
                            <label for="exampleInputEmail1">Avatar</label>
                            <input type="file" name="avatar" class="form-control"  value="<?php echo e($keltan->avatar); ?>">
                            <?php if($errors->has('avatar')): ?>
                                <span class="help-block"><?php echo e($errors->first('avatar')); ?></span>
                            <?php endif; ?>
                        </div>
                            <button type="submit" class="btn btn-warning btn-sm">Update</button>
                    </form>
					</div>
				</div>
              </div>
            </div>
        </div>                  
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/Keltan/edit.blade.php ENDPATH**/ ?>