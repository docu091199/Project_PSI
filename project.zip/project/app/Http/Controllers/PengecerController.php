<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pengecer;
use App\User;

class PengecerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data_pengecer = pengecer::paginate(10);
       return view('DinasPertanian.Pengecer.index',['data_pengecer'=> $data_pengecer]);
    }

    public function create(Request $request)
    {
        $this->validate($request,[
            'pengecer_id'=>'required|unique:pengecer,pengecer_id|min:6',
            'name'=>'required|min:5',
            'region'=>'required',
            'address'=>'required',
            'email'=>'required|unique:users,email',
            'avatar'=>'mimes:jpg,png,jpeg'
        ]);
         //insert to users_table
         $user = new user;
         $user->role = 'pengecer';
         $user->name = $request->name;
         $user->email = $request->email;
         $user->password = bcrypt('rahasia');
         $user->save();

        //insert to pengecer_table    
        $request->request->add(['users_id'=> $user->id]);
        $pengecer = pengecer::create($request->all());

        if($request->hasfile('avatar')){
            $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName());
            $pengecer->avatar=$request->file('avatar')->getClientOriginalName();
            $pengecer->save();
        }

        return redirect('/Pengecer')->with('sukses','Data Berhasil diinput');  
    }

 
    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }

   
    public function edit($id)
    {
        $pengecer = pengecer::find($id);
        return view('DinasPertanian.Pengecer.edit',['pengecer' => $pengecer]);  
    }

  
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'pengecer_id'=>'required|min:6',
            'name'=>'required|min:5',
            'region'=>'required',
            'address'=>'required',
            'avatar'=>'mimes:jpg,png,jpeg'
        ]);

        $pengecer = pengecer::find($id);
        $pengecer->update($request->all());

        if($request->hasfile('avatar')){
            $request->file('avatar')->move('images/',$request->file('avatar')->getClientOriginalName());
            $pengecer->avatar=$request->file('avatar')->getClientOriginalName();
            $pengecer->save();
        }

        return redirect('/Pengecer')->with('sukses','Data Berhasil Diperbaharui');
    }

    function delete($id)
    {
        $pengecer = pengecer::find($id);
        $pengecer->delete($pengecer);
        return redirect('/Pengecer')->with('sukses','Pengecer Berhasil Di non aktifkan (Silahkan Cek Pada Trash Pengecer)');
    }
    public function profile($id){
        $pengecer = pengecer::find($id);
        return view('DinasPertanian.Pengecer.profile',['pengecer' => $pengecer]);
    }
    public function tampil_hapus(Request $request){
        $data_pengecer = pengecer::onlyTrashed()->paginate(10);
        return view('DinasPertanian.Pengecer.nonaktif',['data_pengecer'=>$data_pengecer]);
    }
    public function restore($id){
        $pengecer = pengecer::withTrashed()->where('id', $id)->first();
        $pengecer->restore();
        return redirect()->back()->with('sukses','Pengecer Aktif Kembali(Silahkan Cek Pada List Pengecer)');
    }
    public function kill($id){
        $pengecer = pengecer::withTrashed()->where('id', $id)->first();
        $pengecer->forceDelete();
        return redirect()->back()->with('sukses','Pengecer Berhasil Dihapus');
    }
    public function laporan(Request $request){
        $data_pengecer = pengecer::onlyTrashed()->paginate(10);
        return view('DinasPertanian.Pengecer.nonaktif',['data_pengecer'=>$data_pengecer]);
    }
    
}
