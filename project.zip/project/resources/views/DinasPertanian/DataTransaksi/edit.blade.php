@extends('Layouts.master')

@section('content')
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                <br>
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">UBAH DATA PUPUK BERSUBSIDI</p></b></h1>
                        </div>
                        <div class="panel-body">
                            @if(Session::has('sukses'))
                                <div class="alert alert-success" role="alert">
                                {{Session('sukses') }}
                                </div>
                            @endif
                            <form action = "/Transaksi/{{$transaksi->id}}/update" method="POST">
                                @csrf
                                <div class="form-group {{$errors->has('kode_transaksi') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">KODE TRANSAKSI</label>
                <input type="text" class="form-control" name="kode_transaksi"  placeholder="Masukkan ID" value="{{$transaksi->kode_transaksi}}">
                @if($errors->has('kode_transaksi'))
                  <span class="help-block">{{$errors->first('kode_transaksi')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('nama_pengirim') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Nama Pengirim</label>
                <input type="text" class="form-control" name="nama_pengirim" placeholder="Masukkan Nama Pengirim" value="{{$transaksi->nama_pengirim}}">
                @if($errors->has('nama_pengirim'))
                  <span class="help-block">{{$errors->first('nama_pengirim')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('tanggal_pengiriman') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">Tanggal pengiriman</label>
                <input type="date" class="form-control" name="tanggal_pengiriman"  value="{{$transaksi->tanggal_pengiriman}}">
                @if($errors->has('tanggal_pengiriman'))
                  <span class="help-block">{{$errors->first('tanggal_pengiriman')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('nama_bank') ? 'has-error' : ''}}">
                <label for="exampleInputEmail1">NAMA BANK</label>
                <input type="text" class="form-control" name="nama_bank"  placeholder="Masukkan Nama Bank" value="{{$transaksi->nama_bank}}">
                @if($errors->has('nama_bank'))
                  <span class="help-block">{{$errors->first('nama_bank')}}</span>
                @endif
            </div>
                            <button type="submit" class="btn btn-warning">Update</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection