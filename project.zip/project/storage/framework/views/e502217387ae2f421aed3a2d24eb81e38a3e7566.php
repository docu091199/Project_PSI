

<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-container">
      <div class = "container-fluid">
         <div class = "row">
            <div class = "col-md-12">
              <div class="panel">
			    <div class="panel-heading">
                  <h2 class="panel-title"><b><p class="text-center">DATA PPL YANG SUDAH TIDAK BEROPERASI</p></b></h2>
				</div>
				<div class="panel-body">
                <?php if(Session::has('sukses')): ?>
                <div class="alert alert-success" role="alert">
                 <?php echo e(Session('sukses')); ?>

                </div>
                <?php endif; ?>
				<table class="table table-hover">
					<thead>
						<tr>
                <td>No</td>
                <td>NIP</td>
                <td>NAMA PPL</td>
                <td>JENIS KELAMIN</td>
                <td>LOKASI KERJA</td>
                <td>AKSI</td>
						</tr>
					</thead>
					<tbody>
            <?php $__currentLoopData = $data_ppl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($result + $data_ppl->firstitem()); ?></td>
              <td><a><?php echo e($hasil->ppl_nip); ?></a></td>
              <td><a><?php echo e($hasil->ppl_name); ?></a></td>
              <td><?php echo e($hasil->jenis_kelamin); ?></td>
              <td><?php echo e($hasil->allocation_place); ?></td>
              <td>
              <form action="/PPL/<?php echo e($hasil->id); ?>/kill" method="POST">
                <a href="/PPL/<?php echo e($hasil->id); ?>/aktif" class="btn btn-primary btn-sm">Aktif</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
              <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin menghapus secara permanen??')">Delete</button>
              </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
				</table>
        <?php echo e($data_ppl->links()); ?>

			      </div>
		      </div>
        </div>
      </div>
    </div>
  </div>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/PPL/nonaktif.blade.php ENDPATH**/ ?>