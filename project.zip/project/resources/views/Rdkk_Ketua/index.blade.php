@extends('Layouts.master')

@section('content')
<div class="main">
  <div class="main-container">
    <div class = "container-fluid">
      <div class = "row">
      <br>
        <div class = "col-md-12">
          <div class="panel">
				    <div class="panel-heading">
              <h2 class="panel-title"><b><p class="text-center">Daftar Pengajuan</p></b></h2>
                <div class="right">
                @if(auth()->user()->role=='kelompok')
                  <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>  
                @endif
                </div>
						</div>
						<div class="panel-body">
            @if(Session::has('sukses'))
              <div class="alert alert-success" role="alert">
                {{Session('sukses') }}
              </div>
            @endif             
						<table class="table table-hover">
							<thead>
								<tr>
                  <td>No</td>
                  <td>Nama Kelompok</td>
                  <td>Alamat</td>
                  <td>Nama Pengecer</td>
                
                  <td>Status</td>
                  <td>AKSI</td>
								</tr>
						  </thead>
              <tbody>
                @foreach($rdkk as $result => $hasil)
                <tr>
                  <td>{{$result + 1}}</td>
                  <td>{{$hasil->nama_kelompok}}</td>
                  <td>{{$hasil->alamat}}</td>
                  <td>{{$hasil->nama_pengecer}}</td>
                
                  <td>{{$hasil->status_dinper}}</td>
                  <td><a href="{{route('Pengajuan-rdkk.show',$hasil->id)}}" class="badge badge-infor"><i class="lnr lnr-eye"></i></a>
                     
                  </td>
                </tr>
                @endforeach     
						  </tbody>
						</table>
   
					</div>
				</div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><b>Formulir Pengajuan Rencana Definitif Kebutuhan Kelompok</b></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "{{route('Pengajuan-rdkk.store')}}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group {{$errors->has('nama_kelompok') ? 'has-error' : ''}}">
                <label for="nama_kelompok">Nama Kelompok</label>
                <input type="text" class="form-control @error('nama_kelompok') is-invalid @enderror" name="nama_kelompok"  placeholder="Masukkan Nama Kelompok" value="{{old('nama_kelompok')}}" >
                @if($errors->has('nama_kelompok'))
                  <span class="help-block">{{$errors->first('nama_kelompok')}}</span>
                @endif
    
            </div>
            <div class="form-group {{$errors->has('alamat') ? 'has-error' : ''}}">
                <label for="alamat">Alamat Kelompok</label>
                <input type="text" class="form-control" name="alamat"  placeholder="Masukkan Alamat Kelompok" value="{{old('alamat')}}">
                @if($errors->has('alamat'))
                  <span class="help-block">{{$errors->first('alamat')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('nama_pengecer') ? 'has-error' : ''}}">
                <label for="nama_pengecer">Nama Pengecer</label>
                <select name="nama_pengecer" class="form-control" id="nama_pengecer">
                    <option placeholder>Select...</option>
                    @foreach($pengecer as $hasil => $lop)
                    <option >{{$lop->name}}</option>
                    @endforeach
                </select>
                @if($errors->has('nama_pengecer'))
                  <span class="help-block">{{$errors->first('nama_pengecer')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('luas_tanah') ? 'has-error' : ''}}">
                <label for="luas_tanah">Luas Tanah</label>
                <input type="text" class="form-control @error('luas_tanah') is-invalid @enderror" name="luas_tanah"  placeholder="Masukkan Luas Tanah" value="{{old('luas_tanah')}}">
                @if($errors->has('luas_tanah'))
                  <span class="help-block">{{$errors->first('luas_tanah')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('nama_pupuk') ? 'has-error' : ''}}">
                <label for="nama_pupuk">Nama Pupuk</label>
                <input type="text" class="form-control" name="nama_pupuk"  placeholder="Masukkan Nama Pupuk" value="{{old('nama_pupuk')}}">
                @if($errors->has('nama_pupuk'))
                  <span class="help-block">{{$errors->first('nama_pupuk')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('jumlah_pupuk') ? 'has-error' : ''}}">
                <label for="jumlah_pupuk">Jumlah Pupuk</label>
                <input type="text" class="form-control" name="jumlah_pupuk"  placeholder="Masukkan Jumlah Pupuk" value="{{old('jumlah_pupuk')}}">
                @if($errors->has('jumlah_pupuk'))
                  <span class="help-block">{{$errors->first('jumlah_pupuk')}}</span>
                @endif
            </div>
            <div class="form-group {{$errors->has('waktu_penggunaan') ? 'has-error' : ''}}">
                <label for="waktu_penggunaan">Waktu Penggunaan</label>
                <input type="date" class="form-control" name="waktu_penggunaan"  value="{{old('waktu_penggunaan')}}">
                @if($errors->has('waktu_penggunaan'))
                  <span class="help-block">{{$errors->first('waktu_penggunaan')}}</span>
                @endif
            </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>

@endsection

 

