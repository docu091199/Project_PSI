

<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-container">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-12">
                    <div class="panel">
				        <div class="panel-heading">
					    <h1 class="panel-title"><b><p class="text-center">UBAH DATA PUPUK BERSUBSIDI</p></b></h1>
                        </div>
                        <div class="panel-body">
                            <?php if(Session::has('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(Session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                            <form action = "/Pupuk/<?php echo e($pupuk->id); ?>/update" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group <?php echo e($errors->has('pupuk_id') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">KODE</label>
                                    <input type="text" class="form-control" name="pupuk_id"  placeholder="Masukkan KODE PUPUK" value="<?php echo e($pupuk->pupuk_id); ?>">
                                    <?php if($errors->has('pupuk_id')): ?>
                                    <span class="help-block"><?php echo e($errors->first('pupuk_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">NAMA Pupuk</label>
                                    <input type="text" class="form-control" name="name"  placeholder="Masukkan Nama Pupuk" value="<?php echo e($pupuk->name); ?>">
                                    <?php if($errors->has('name')): ?>
                                    <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('jenis') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">PILIH JENIS PUPUK</label>
                                    <select name="jenis" class="form-control" id="exampleformControlSelect1">
                                        <option placeholder>select...</option>
                                        <option value="Kimia">Kimia</option>
                                        <option value="Organik">Organik</option>
                                    </select>
                                    <?php if($errors->has('jenis')): ?>
                                    <span class="help-block"><?php echo e($errors->first('jenis')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('harga') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">HARGA PUPUK</label>
                                    <input type="text" class="form-control" name="harga"  placeholder="Masukkan Harga Pupuk(Rp)" value="<?php echo e($pupuk->harga); ?>">
                                    <?php if($errors->has('harga')): ?>
                                    <span class="help-block"><?php echo e($errors->first('harga')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('jumlah_pupuk') ? 'has-error' : ''); ?>">
                                    <label for="exampleInputEmail1">JUMLAH PEMESANAN PUPUK</label>
                                    <input type="text" class="form-control" name="jumlah_pupuk"  placeholder="Masukkan Harga Pupuk(Rp)" value="<?php echo e($pupuk->jumlah_pupuk); ?>">
                                    <?php if($errors->has('jumlah_pupuk')): ?>
                                    <span class="help-block"><?php echo e($errors->first('jumlah_pupuk')); ?></span>
                                    <?php endif; ?>
                                </div>
                            <button type="submit" class="btn btn-warning">Update</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/Pupuk/edit.blade.php ENDPATH**/ ?>