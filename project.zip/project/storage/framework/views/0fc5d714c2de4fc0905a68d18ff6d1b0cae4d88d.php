

<?php $__env->startSection('content'); ?>

<div class="main">
  <div class="main-container">
    <div class = "container-fluid">
      <div class = "row">
        <div class = "col-md-12">
          <br>
          <div class="panel">
					  <div class="panel-heading">
              <h2 class="panel-title"><b><p class="text-center">DATA PENGECER RESMI</p></b></h2>
                <div class="right">
                  <button type="button" class="button btn-lg"><i class=" lnr lnr-plus-circle" data-toggle="modal" data-target="#exampleModal"></i></button>
                </div>
					  </div>
					  <div class="panel-body">
              <?php if(Session::has('sukses')): ?>
              <div class="alert alert-success" role="alert">
              <?php echo e(Session('sukses')); ?>

              </div>
              <?php endif; ?>
						    <table class="table table-hover">
								  <thead>
									  <tr>
                      <td>No</td>
                      <td>ID</td>
                      <td>NAMA PENGECER</td>
                      <td>REGION</td>
                      <td>ALAMAT</td>
                      <td>AKSI</td>
									</tr>
								</thead>
								<tbody>
                <?php $__currentLoopData = $data_pengecer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($result + $data_pengecer->firstitem()); ?></td>
                    <td><a href="/Pengecer/<?php echo e($hasil->id); ?>/profile"><?php echo e($hasil->pengecer_id); ?></a></td>
                    <td><a href="/Pengecer/<?php echo e($hasil->id); ?>/profile"><?php echo e($hasil->name); ?></a></td>
                    <td><?php echo e($hasil->region); ?></td>
                    <td><?php echo e($hasil->address); ?></td>
                    <td><a href="/Pengecer/<?php echo e($hasil->id); ?>/edit" class="btn btn-warning btn-sm"> Edit</a>
                        <a href="/Pengecer/<?php echo e($hasil->id); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin mengganti status??')">Non Aktif</a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
						    </table>
                <?php echo e($data_pengecer->links()); ?> 
					  </div>
          </div>
        </div>
      </div>
    </div>
  </div>  
</div> 
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Masukkan Data Pengecer Resmi</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action = "/Pengecer/create" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('pengecer_id') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">ID Pengecer</label>
                <input type="text" class="form-control" name="pengecer_id"  placeholder="Masukkan ID" value="<?php echo e(old('pengecer_id')); ?>">
                <?php if($errors->has('pengecer_id')): ?>
                  <span class="help-block"><?php echo e($errors->first('pengecer_id')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Nama Pengecer</label>
                <input type="text" class="form-control" name="name" placeholder="Masukkan Nama Pengecer (Toko Resmi)" value="<?php echo e(old('name')); ?>">
                <?php if($errors->has('name')): ?>
                  <span class="help-block"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('region') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Region</label>
                <input type="text" class="form-control" name="region"  placeholder="Masukkan Region" value="<?php echo e(old('region')); ?>">
                <?php if($errors->has('region')): ?>
                  <span class="help-block"><?php echo e($errors->first('region')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                <label for="exampleInputTextarea1">Alamat</label>
                <textarea type="text" class="form-control" name="address"  placeholder="Masukkan Alamat" ><?php echo e(old('address')); ?></textarea>
                <?php if($errors->has('address')): ?>
                  <span class="help-block"><?php echo e($errors->first('address')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <label for="exampleInputEmail1">Email</label>
                <input type="email" class="form-control" name="email"  placeholder="Masukkan Email" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                  <span class="help-block"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Avatar</label>
              <input type="file" name="avatar" class="form-control"  value="<?php echo e(old('avatar')); ?>">
            </div>
            <div class="form-group form-check <?php echo e($errors->has('avatar') ? 'has-error' : ''); ?>">
                <?php if($errors->has('avatar')): ?>
                  <span class="help-block"><?php echo e($errors->first('avatar')); ?></span>
                <?php endif; ?>
            </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\docu\PROJECT PSI\project\resources\views/DinasPertanian/Pengecer/index.blade.php ENDPATH**/ ?>